package ualg.les.libapp.test;

import junit.framework.Assert;

import com.jayway.android.robotium.solo.Solo;

import ualg.les.libapp.AtualizarActivity;
import ualg.les.libapp.MenuActivity;
import android.test.ActivityInstrumentationTestCase2;

public class AtualizarTest extends
		ActivityInstrumentationTestCase2<MenuActivity> {

	public AtualizarTest()
	{
		super(MenuActivity.class);
	}

	private Solo solo;
	
	protected void setUp() throws Exception
	{
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}
	
	/*
	 * Testa se est� a ser mostrado o menu
	 */
	public void testMenuActivity()
	{
		solo.assertCurrentActivity("Menu", MenuActivity.class);
	}
	
	/*
	 * Testa atualiza��o com internet desligada
	 */
	public void testMenuActivityAtualizacaoInternetDesligada()
	{
		solo.assertCurrentActivity("Menu", MenuActivity.class);
		solo.clickOnText("Atualizar");
		solo.clickOnText("Fechar");
		solo.assertCurrentActivity("Menu", MenuActivity.class);
	}

	/*
	 * Testa atualiza��o com internet ligada
	 */
	public void testMenuActivityAtualizacaoInternetLigada()
	{
		solo.assertCurrentActivity("Menu", MenuActivity.class);
		solo.clickOnText("Atualizar");
		if(solo.searchText("Autentica��o"))
		{
			solo.enterText(0, "admin");
			solo.enterText(1, "admin");
			solo.clickOnText("Continuar");
		}
		solo.assertCurrentActivity("Atualizar", AtualizarActivity.class);
		
		solo.clickOnText("Atualizar Dados");
		solo.waitForDialogToClose(60000);
		Assert.assertTrue(solo.searchText("exito"));
		solo.clickOnText("Fechar");
		
		solo.clickOnText("Atualizar Imagens");
		solo.waitForDialogToClose(60000);
		Assert.assertTrue(solo.searchText("exito"));
		solo.clickOnText("Fechar");
		
		solo.clickOnText("Enviar Contributos");
		solo.waitForDialogToClose(60000);
		Assert.assertTrue(solo.searchText("exito"));
		solo.clickOnText("Fechar");
	}
}
