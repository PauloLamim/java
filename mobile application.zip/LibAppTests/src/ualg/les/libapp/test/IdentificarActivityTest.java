package ualg.les.libapp.test;

import com.jayway.android.robotium.solo.Solo;

import ualg.les.libapp.FichaActivity;
import ualg.les.libapp.IdentificarActivity;
import ualg.les.libapp.IdentificarResultadosActivity;
import android.test.ActivityInstrumentationTestCase2;

public class IdentificarActivityTest extends
		ActivityInstrumentationTestCase2<IdentificarActivity> {

	public IdentificarActivityTest()
	{
		super(IdentificarActivity.class);
	}

	private Solo solo;
	
	protected void setUp() throws Exception
	{
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}

	/*
	 * Testa se est� a ser mostrada a ferramenta de identifica��o
	 */
	public void testIdentificarActivity()
	{
		solo.assertCurrentActivity("Identifica��o", IdentificarActivity.class);
	}
	
	/*
	 * Testa uma identifica��o e o respetivo resultado
	 */
	public void testIdentificarActivityIdentificacao()
	{
		solo.assertCurrentActivity("Identifica��o", IdentificarActivity.class);
		solo.clickOnRadioButton(0);
		solo.clickOnCheckBox(0);
		solo.clickOnText("Identificar");
		solo.assertCurrentActivity("Resultados Identifica��o", IdentificarResultadosActivity.class);
		solo.clickOnText("1�");
		solo.assertCurrentActivity("Ficha", FichaActivity.class);
	}
}
