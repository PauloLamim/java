package ualg.les.libapp.test;

import com.jayway.android.robotium.solo.Solo;

import ualg.les.libapp.FichaActivity;
import ualg.les.libapp.FichasEspeciesActivity;
import android.test.ActivityInstrumentationTestCase2;

public class FichasEspeciesActivityTest extends
		ActivityInstrumentationTestCase2<FichasEspeciesActivity> {

	public FichasEspeciesActivityTest()
	{
		super(FichasEspeciesActivity.class);
	}

	private Solo solo;
	
	protected void setUp() throws Exception
	{
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}
	
	/*
	 * Testa se est�o a ser mostradas as fichas de especies
	 */
	public void testFichasEspeciesActivity()
	{
		solo.assertCurrentActivity("Fichas de especies", FichasEspeciesActivity.class);
	}

	/*
	 * Testa se uma ficha individual est� a ser mostrada apartir da lista das fichas
	 */
	public void testFichasEspeciesActivityIrParaEspecie()
	{
		solo.assertCurrentActivity("Fichas de especies", FichasEspeciesActivity.class);
		solo.clickOnText("- Aeshna cyanea");
		solo.assertCurrentActivity("Ficha", FichaActivity.class);
		solo.goBack();
		solo.assertCurrentActivity("Fichas de especies", FichasEspeciesActivity.class);
	}
}
