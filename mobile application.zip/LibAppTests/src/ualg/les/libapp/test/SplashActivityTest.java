package ualg.les.libapp.test;

import com.jayway.android.robotium.solo.Solo;

import ualg.les.libapp.MenuActivity;
import ualg.les.libapp.SplashActivity;
import android.test.ActivityInstrumentationTestCase2;

public class SplashActivityTest extends ActivityInstrumentationTestCase2<SplashActivity>
{	
	public SplashActivityTest()
	{
		super(SplashActivity.class);
	}

	private Solo solo;
	
	protected void setUp() throws Exception
	{
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}

	/*
	 * Testa se est� a ser mostrada o SpashScreen
	 */
	public void testSplashActivity()
	{
		solo.assertCurrentActivity("Spash", SplashActivity.class);
	}
	
	/*
	 * Testa se o menu aparece automaticamente depois do SpashScreen
	 */
	public void testSplashActivityTransicao()
	{
		solo.assertCurrentActivity("Spash", SplashActivity.class);
		solo.assertCurrentActivity("Menu", MenuActivity.class);
	}
}
