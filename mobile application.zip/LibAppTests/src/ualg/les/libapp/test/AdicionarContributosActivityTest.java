package ualg.les.libapp.test;

import junit.framework.Assert;

import com.jayway.android.robotium.solo.Condition;
import com.jayway.android.robotium.solo.Solo;

import ualg.les.libapp.AdicionarContributosActivity;
import ualg.les.libapp.MenuActivity;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.TextView;

public class AdicionarContributosActivityTest extends
		ActivityInstrumentationTestCase2<AdicionarContributosActivity> {

	public AdicionarContributosActivityTest()
	{
		super(AdicionarContributosActivity.class);
	}

	private Solo solo;
	
	protected void setUp() throws Exception
	{
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}
	
	/*
	 * Testa se est� a ser mostrado o formulario de introdu��o de contributos
	 */
	public void testAdicionarContributosActivity()
	{
		solo.assertCurrentActivity("Adicionar Contributos", AdicionarContributosActivity.class);
	}
	
	/*
	 * Testa a introdu��o de um contributo com o GPS inicialmente desligado
	 */
//	public void testAdicionarContributosActivityAdicionarGPSDesligado()
//	{
//		solo.assertCurrentActivity("Adicionar Contributos", AdicionarContributosActivity.class);
//		Assert.assertTrue(solo.searchText("Aten��o!"));
//		solo.clickOnText("Sim");
//		solo.clickOnCheckBox(1);
//		solo.goBack();
//		solo.waitForCondition(new Condition() {
//			
//			@Override
//			public boolean isSatisfied()
//			{
//				TextView gps = (TextView) solo.getView(ualg.les.libapp.R.id.lat_lon);
//				
//				if(!gps.getText().equals("") && !gps.getText().equals("A obter localiza��o...") && !gps.getText().equals("GPS desligado."))
//					return true;
//				else
//					return false;
//			}
//			
//		}, 10000);
//		solo.clickOnText("Submeter");
//		Assert.assertTrue(solo.searchText("Contrubuto inserido com sucesso!"));
//		solo.clickOnText("Ok");
//		solo.assertCurrentActivity("Menu", MenuActivity.class);
//		solo.clickOnText("Contribuir");
//		solo.assertCurrentActivity("Contribuir", AdicionarContributosActivity.class);
//	}
	
	/*
	 * Testa a introdu��o de um contributo com o GPS inicialmente ligado
	 */
	public void testAdicionarContributosActivityAdicionarGPSLigado()
	{
		solo.assertCurrentActivity("Adicionar Contributos", AdicionarContributosActivity.class);
		solo.waitForCondition(new Condition() {
			
			@Override
			public boolean isSatisfied()
			{
				TextView gps = (TextView) solo.getView(ualg.les.libapp.R.id.lat_lon);
				
				if(!gps.getText().equals("") && !gps.getText().equals("A obter localiza��o...") && !gps.getText().equals("GPS desligado."))
					return true;
				else
					return false;
			}
			
		}, 10000);
		solo.clickOnText("Submeter");
		Assert.assertTrue(solo.searchText("Contrubuto inserido com sucesso!"));
		solo.clickOnText("Ok");
		solo.assertCurrentActivity("Menu", MenuActivity.class);
		solo.clickOnText("Contribuir");
		solo.assertCurrentActivity("Contribuir", AdicionarContributosActivity.class);
	}
}
