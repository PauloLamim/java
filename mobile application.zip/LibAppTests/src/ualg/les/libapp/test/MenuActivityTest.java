package ualg.les.libapp.test;

import junit.framework.Assert;

import com.jayway.android.robotium.solo.Solo;

import ualg.les.libapp.AdicionarContributosActivity;
import ualg.les.libapp.FichasEspeciesActivity;
import ualg.les.libapp.GuiaCampoActivity;
import ualg.les.libapp.IdentificarActivity;
import ualg.les.libapp.MenuActivity;
import android.test.ActivityInstrumentationTestCase2;

public class MenuActivityTest extends ActivityInstrumentationTestCase2<MenuActivity>
{

	public MenuActivityTest()
	{
		super(MenuActivity.class);
	}

	private Solo solo;
	
	protected void setUp() throws Exception
	{
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}
	
	/*
	 * Testa se est� a ser mostrado o menu
	 */
	public void testMenuActivity()
	{
		solo.assertCurrentActivity("Menu", MenuActivity.class);
	}
	
	/*
	 * Testa bot�o Guia de Campo
	 */
	public void testMenuActivityGuiaDeCampo()
	{
		solo.assertCurrentActivity("Menu", MenuActivity.class);
		solo.clickOnText("Guia de Campo");
		solo.assertCurrentActivity("Guia de Campo", GuiaCampoActivity.class);
		solo.goBack();
		solo.assertCurrentActivity("Menu", MenuActivity.class);
	}
	
	/*
	 * Testa bot�o Fichas de Esp�cie
	 */
	public void testMenuActivityFichasDeEspecie()
	{
		solo.assertCurrentActivity("Menu", MenuActivity.class);
		solo.clickOnText("Fichas de Esp�cie");
		solo.assertCurrentActivity("Fichas de Esp�cie", FichasEspeciesActivity.class);
		solo.goBack();
		solo.assertCurrentActivity("Menu", MenuActivity.class);
	}
	
	/*
	 * Testa bot�o Identificar
	 */
	public void testMenuActivityIdentificar()
	{
		solo.assertCurrentActivity("Menu", MenuActivity.class);
		solo.clickOnText("Identificar");
		solo.assertCurrentActivity("Identificar", IdentificarActivity.class);
		solo.goBack();
		solo.assertCurrentActivity("Menu", MenuActivity.class);
	}
	
	/*
	 * Testa bot�o Contribuir
	 */
	public void testMenuActivityContribuir()
	{
		solo.assertCurrentActivity("Menu", MenuActivity.class);
		solo.clickOnText("Contribuir");
		solo.assertCurrentActivity("Contribuir", AdicionarContributosActivity.class);
		if(solo.searchText("Aten��o!"))
		{
			solo.clickOnText("N�o");
		}
		solo.goBack();
		solo.assertCurrentActivity("Menu", MenuActivity.class);
	}
	
	// O bot�o atualizar � testado num Test Case proprio
}
