package ualg.les.libapp.test;

import com.jayway.android.robotium.solo.Solo;

import ualg.les.libapp.GuiaCampoActivity;
import android.test.ActivityInstrumentationTestCase2;

public class GuiaCampoActivityTest extends
		ActivityInstrumentationTestCase2<GuiaCampoActivity> {

	public GuiaCampoActivityTest()
	{
		super(GuiaCampoActivity.class);
	}

	private Solo solo;
	
	protected void setUp() throws Exception
	{
		super.setUp();
		solo = new Solo(getInstrumentation(), getActivity());
	}
	
	/*
	 * Testa se est� a ser mostrado o guia de campo
	 */
	public void testGuiaCampoActivity()
	{
		solo.assertCurrentActivity("Guia de Campo", GuiaCampoActivity.class);
	}
}
