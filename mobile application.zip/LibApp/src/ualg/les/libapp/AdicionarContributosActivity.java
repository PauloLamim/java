package ualg.les.libapp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.os.Bundle;
import android.provider.Settings;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.util.Pair;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class AdicionarContributosActivity extends Activity implements OnItemSelectedListener
{
	public class Coordenadas
	{
		public double latitude;
		public double longitude;
		
		public Coordenadas()
		{
			this.latitude = 0;
			this.longitude = 0;
		}
		
		public void setCoordenadas(double lat, double lon)
		{
			this.latitude = lat;
			this.longitude = lon;
		}
	}
	
	private GPSAdapter gps;
	
	private Coordenadas coordenadas;
	
	private String especie;
	private String estadio;
	private String exemplares;
	
	private List<String> estadios_nome;
	private List<String> estadios_descricao;
	
	private List<String> exemplares_nome;
	private List<String> exemplares_descricao;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adicionar_contributos_activity);
		
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		// especies
		
		List<String> especies = dba.getEspecies();
		
		ArrayAdapter<String> adapter_especies = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, especies);
		adapter_especies.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
				
		Spinner spinner_especies = (Spinner) findViewById(R.id.add_contributo_especies);
		spinner_especies.setAdapter(adapter_especies);
		spinner_especies.setOnItemSelectedListener(this);

		// estadios
		
		List<Pair<String, String>> estadios = dba.getEstadios();
		
		estadios_nome = new ArrayList<String>();

		estadios_descricao = new ArrayList<String>();
		
		for(Pair<String, String> estadio : estadios)
		{
			estadios_nome.add(estadio.first);
			estadios_descricao.add(estadio.second);
		}
		
		ArrayAdapter<String> adapter_estadios = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, estadios_descricao);
		adapter_estadios.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
				
		Spinner spinner_estadios = (Spinner) findViewById(R.id.add_contributo_estadios);
		spinner_estadios.setAdapter(adapter_estadios);
		spinner_estadios.setOnItemSelectedListener(this);
//		
//		// exemplares

		List<Pair<String, String>> n_exemplares = dba.getExemplares();
		
		exemplares_nome = new ArrayList<String>();

		exemplares_descricao = new ArrayList<String>();
		
		for(Pair<String, String> n_exemplar : n_exemplares)
		{
			exemplares_nome.add(n_exemplar.first);
			exemplares_descricao.add(n_exemplar.second);
			
			Log.i("debug", n_exemplar.first + " " + n_exemplar.second);
		}
		
		ArrayAdapter<String> adapter_n_exemplares = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, exemplares_descricao);
		adapter_n_exemplares.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
				
		Spinner spinner_n_exemplares = (Spinner) findViewById(R.id.add_contributo_numeroexemplares);
		spinner_n_exemplares.setAdapter(adapter_n_exemplares);
		spinner_n_exemplares.setOnItemSelectedListener(this);
		
		dba.close();
		
		// GPS stuff
		
		coordenadas = new Coordenadas();	
		
		gps = new GPSAdapter(this, coordenadas);
		
		TextView latlon = (TextView)findViewById(R.id.lat_lon);
		
		gps.setUpdateView(latlon);
				
        if(gps.gpsOk())
        {			
			latlon.setText("A obter localiza��o...");
			
        	//Log.i("debug", "Latitude: " + gps.getLat() + "\nLongitude: " + gps.getLon());
        }
        else
        {
        	gpsDialog();
        	
        	Log.w("debug", "Provider not enabled");
        }
	}

	private void gpsDialog()
	{
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

		// set title
		alertDialogBuilder.setTitle("Aten��o!");

		// set dialog message
		alertDialogBuilder
		.setMessage("Para adicionar um contributo � necess�rio obter a sua localiza��o atrav�s do GPS.\nDeseja activar o GPS?")
		.setCancelable(false)
		.setPositiveButton("Sim", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
	            startActivity(myIntent);
	            
	            TextView latlon = (TextView)findViewById(R.id.lat_lon);
				
				latlon.setText("A obter localiza��o...");
				
	            dialog.cancel();
			}
		})
		.setNegativeButton("N�o", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				TextView latlon = (TextView)findViewById(R.id.lat_lon);
				
				latlon.setText("GPS desligado.");
				
				dialog.cancel();
			}
		});

		// create alert dialog
		AlertDialog alertDialog = alertDialogBuilder.create();

		// show it
		alertDialog.show();
	}
	
	private void goToMenu()
	{
		Intent intent = new Intent(this, MenuActivity.class);	
        startActivity(intent);
	}
	
	@SuppressLint("SimpleDateFormat")
	public void addContributo(View v)
	{
		// teste
		//coordenadas.setCoordenadas(8.2, 3.1);
		//
		if(!gps.gpsOk() && coordenadas.latitude == 0 && coordenadas.longitude == 0) // GPS desligado e sem coordenadas
		{
			gpsDialog();
		}
		else if(gps.gpsOk() && coordenadas.latitude == 0 && coordenadas.longitude == 0) // GPS ligado a obter localiza��o
		{
			TextView latlon = (TextView)findViewById(R.id.lat_lon);
			
			latlon.setText("A obter localiza��o...");
			
			Toast.makeText(this, "A obter localiza��o...", Toast.LENGTH_LONG).show();
		}
		else if(coordenadas.latitude != 0 && coordenadas.longitude != 0) // GPS ligado ou desligado mas com coordenadas
		{
			Calendar c = Calendar.getInstance();
			SimpleDateFormat df = new SimpleDateFormat("dd/MMM/yyyy");
			String date = df.format(c.getTime());
			
			EditText observacoes_view = (EditText)findViewById(R.id.add_contributo_observacoes);
			String observacoes = observacoes_view.getText().toString();
			
			
			DBAdapter dba = new DBAdapter(this);
			dba.open();
						
			if(dba.createContributo(coordenadas.latitude, coordenadas.longitude, especie, estadio, exemplares, observacoes, date) != -1)
			{
				AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

				// set title
				//alertDialogBuilder.setTitle("Contributo");

				// set dialog message
				alertDialogBuilder
				.setMessage("Contrubuto inserido com sucesso!")
				.setCancelable(false)
				.setNeutralButton("Ok", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
						goToMenu();
			            dialog.cancel();
					}
				});

				// create alert dialog
				AlertDialog alertDialog = alertDialogBuilder.create();

				// show it
				alertDialog.show();
				
				//Toast.makeText(this, "Contributo inserido!", Toast.LENGTH_LONG).show();
			}
			else
			{
				AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

				// set title
				//alertDialogBuilder.setTitle("Contributo");

				// set dialog message
				alertDialogBuilder
				.setMessage("Erro ao inserir contributo.\nPor favor, tente novamente.")
				.setCancelable(false)
				.setNeutralButton("Ok", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
			            dialog.cancel();
					}
				});

				// create alert dialog
				AlertDialog alertDialog = alertDialogBuilder.create();

				// show it
				alertDialog.show();
				
				Log.i("debug", "Erro!");
				//Toast.makeText(this, "Erro!", Toast.LENGTH_LONG).show();
			}
			
			dba.close();
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.adicionar_contributos, menu);
		return true;
	}

	public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
	{       
        if(parent.getId() == R.id.add_contributo_especies)
        {
        	especie = (String) parent.getItemAtPosition(pos);
        	//Toast.makeText(this, especie, Toast.LENGTH_LONG).show();
        }
        if(parent.getId() == R.id.add_contributo_estadios)
        {
        	//estadio = (String) parent.getItemAtPosition(pos);
        	
        	estadio = estadios_nome.get(pos);
        	
        	//Toast.makeText(this, estadio, Toast.LENGTH_LONG).show();
        }
        if(parent.getId() == R.id.add_contributo_numeroexemplares)
        {
        	//exemplares = (String) parent.getItemAtPosition(pos);
        	
        	exemplares = exemplares_nome.get(pos);
        	
        	//Toast.makeText(this, exemplares, Toast.LENGTH_LONG).show();
        }
    }

    public void onNothingSelected(AdapterView<?> parent)
    {
        // Another interface callback
    }
}
