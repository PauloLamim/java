package ualg.les.libapp;

import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Typeface;
import android.util.Pair;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GuiaCampoActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.guia_campo_activity);
		
		ViewGroup layout = (ViewGroup) findViewById(R.id.guia_de_campo);
		
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		List<Pair<String, String>> textos = dba.getTextos();
		
		dba.close();
		
		for(Pair<String, String> texto : textos)
		{
			LinearLayout texto_wraper = new LinearLayout(this);
			texto_wraper.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
			texto_wraper.setOrientation(LinearLayout.VERTICAL);
			
			float density = this.getResources().getDisplayMetrics().density;
			
			texto_wraper.setBackgroundResource(R.drawable.btn_default);
			texto_wraper.setPadding((int) (15*density), (int) (10*density), (int) (15*density), (int) (10*density));
			
			TextView titulo = new TextView(this); // titulo
			LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			ll.setMargins(0, 0, 0, 10);
			titulo.setLayoutParams(ll);
			titulo.setTextAppearance(this, android.R.style.TextAppearance_Large);
			titulo.setTypeface(null, Typeface.BOLD);
			titulo.setText(texto.first);
			
			texto_wraper.addView(titulo);
			
			
			TextView conteudo = new TextView(this); // titulo
			LinearLayout.LayoutParams ll2 = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			ll2.setMargins(0, 0, 0, 20);
			conteudo.setLayoutParams(ll2);
			conteudo.setTextAppearance(this, android.R.style.TextAppearance_Medium);
			conteudo.setText(texto.second);
			
			texto_wraper.addView(conteudo);
			
			layout.addView(texto_wraper);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.guia_campo_activity, menu);
		return true;
	}

}
