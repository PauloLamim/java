package ualg.les.libapp;

import java.io.File;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

public class ImagemActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.imagem_activity);
		
		//
		
		Intent intent = getIntent();
		String path = intent.getExtras().getString("path");
		
		File imgFile = new File(path);
		
		if(imgFile.exists())
		{
			Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
			
			ImageViewTouch imagem = (ImageViewTouch)findViewById(R.id.image);
						
			imagem.setImageBitmapReset(myBitmap, true);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.imagem, menu);
		return true;
	}

}
