package ualg.les.libapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import android.content.Context;
import android.util.Log;
import android.util.Pair;

public class Identificacao
{
	private class Especie
	{
		private String nome;
		private int count;
		
		public Especie(String n)
		{
			setNome(n);
			count = 0;
		}
		
		public String getNome()
		{
			return nome;
		}

		public void setNome(String nome)
		{
			this.nome = nome;
		}
		
		public void increment()
		{
			count++;
		}
		
		public int getCount()
		{
			return count;
		}
	}
	
	private class compareEspecies implements Comparator<Especie>
	{
	    public int compare(Especie object1, Especie object2)
	    {
	        if(object1.getCount() < object2.getCount())
	        	return 1;
	        else if(object1.getCount() > object2.getCount())
	        	return -1;
	        else
	        	return 0;
	    }
	}
	
	private DBAdapter dba;
	
	private List<Especie> especies = new ArrayList<Especie>();
	
	public Identificacao(Context c)
	{
		dba = new DBAdapter(c);
		dba.open();
		
		List<String> e = dba.getEspecies();
		
		for(String especie : e)
			especies.add(new Especie(especie));
	}
	
	public List<String> filterEspecies(List<Pair<String, String>> filters, String habitat, String mes)
	{
		for(Pair<String, String> filter : filters)
		{
			for(Especie especie : especies)
			{
				if(dba.especieHasAtribute(especie.getNome(), filter.first, filter.second))
				{
					especie.increment();
				}
			}
		}
		
		Collections.sort(especies, new compareEspecies());
		
		List<String> e = new ArrayList<String>();
		
		for(Especie especie : especies)
		{
			if((!mes.equals("") && dba.especieHasEpocaVoo(especie.getNome(), mes)) || mes.equals(""))
			{
				if((!habitat.equals("") && dba.especieHasHabitat(especie.getNome(), habitat)) || habitat.equals(""))
				{
					e.add(especie.getNome());
					Log.i("debug", especie.getNome() + ": " + especie.getCount());
				}
			}
		}
		
		return e;
	}
}
