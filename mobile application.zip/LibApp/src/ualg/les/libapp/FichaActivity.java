package ualg.les.libapp;

import java.io.File;
import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;
import android.util.Pair;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FichaActivity extends Activity {

	String especie;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ficha_activity);
		
		Intent intent = getIntent();
		especie = intent.getExtras().getString("especie");
		
		ViewGroup layout = (ViewGroup) findViewById(R.id.ficha_conteudo);
		
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		TextView tv1 = (TextView) findViewById(R.id.ficha_titulo);
		TextView tv2 = (TextView) findViewById(R.id.ficha_descoberta);
		TextView tv3 = (TextView) findViewById(R.id.ficha_ingles);
		TextView tv4 = (TextView) findViewById(R.id.ficha_subordem);
		TextView tv5 = (TextView) findViewById(R.id.ficha_familia);
		TextView tv6 = (TextView) findViewById(R.id.ficha_estatuto);
		TextView tv7 = (TextView) findViewById(R.id.ficha_tendencia);
		
		LinearLayout view_habitats = (LinearLayout) findViewById(R.id.ficha_habitats);
		TextView tv9 = (TextView) findViewById(R.id.ficha_identificacao);
		TextView tv10 = (TextView) findViewById(R.id.ficha_outrasinfo);
		
		tv1.setText(especie);
		tv2.setText("(" + dba.getEspecieDescoberta(especie) + ")");
		tv3.setText("Nome ingl�s: " + dba.getEspecieIngles(especie));
		tv4.setText("Subordem: " + dba.getEspecieSubOrdem(especie));
		tv5.setText("Familia: " + dba.getEspecieFamilia(especie));
		tv6.setText("Estatuto de Conserva��o (EU27 Red List 2010): " + dba.getEspecieEstatuto(especie));
		tv7.setText("Tend�ncia: " + dba.getEspecieTendencia(especie));
				
		List<Pair<String, String>> habitats = dba.getEspecieHabitats(especie);
		
		for(Pair<String, String> habitat : habitats)
		{
			TextView tipo = new TextView(this);
			LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			ll.setMargins(0, 5, 0, 5);
			tipo.setLayoutParams(ll);
			tipo.setTextAppearance(this, android.R.style.TextAppearance_Medium);
			tipo.setTypeface(null, Typeface.BOLD);
			tipo.setText(habitat.first);
			
			view_habitats.addView(tipo);
			
			TextView subtipo = new TextView(this);
			subtipo.setLayoutParams(ll);
			subtipo.setTextAppearance(this, android.R.style.TextAppearance_Medium);
			subtipo.setText(habitat.second);
			
			view_habitats.addView(subtipo);
		}
		
		tv9.setText(dba.getEspecieIdentificacao(especie));
		tv10.setText(dba.getEspecieInfo(especie));
		
		String PATH = this.getFilesDir().getPath();
		
		Log.i("debug", PATH + "/" + dba.getImagens(especie));
		
		List<Pair<String, String>> imagens = dba.getImagens(especie);
		
		if(!imagens.isEmpty())
		{
			final String path = PATH + "/" + imagens.get(0).first;
			
			File imgFile = new File(path);
			if(imgFile.exists())
			{
				float density = this.getResources().getDisplayMetrics().density;
				
			    Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
	
			    ImageView myImage = (ImageView) findViewById(R.id.ficha_imagem);
			    LinearLayout.LayoutParams ivll = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				ivll.setMargins((int) (5*density), (int) (5*density), (int) (5*density), 0);
			    myImage.setLayoutParams(ivll);
				myImage.setImageBitmap(myBitmap);
			    myImage.setBackgroundColor(Color.WHITE);
			    myImage.setPadding((int) (5*density), (int) (5*density), (int) (5*density), (int) (5*density));
			    myImage.setOnClickListener(new OnClickListener()
			    {					
					@Override
					public void onClick(View v)
					{
						mostrarImagem(path);
					}
				});
			    
			    TextView legenda = new TextView(this);
				LinearLayout.LayoutParams ll1 = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				ll1.setMargins((int) (5*density), 0, (int) (5*density), (int) (5*density));
				legenda.setLayoutParams(ll1);
				legenda.setGravity(Gravity.CENTER_HORIZONTAL);
				legenda.setTextAppearance(this, android.R.style.TextAppearance_Small);
				legenda.setBackgroundColor(Color.WHITE);
				legenda.setTextColor(Color.BLACK);
				legenda.setText(imagens.get(0).second);
				
				((LinearLayout)(myImage.getParent())).addView(legenda);
			}
			else
				Log.e("debug", "Imagem n�o encontrada.");
		}
		
		if(imagens.size() > 1)
		{
			float density = this.getResources().getDisplayMetrics().density;
			
			for(int i = 1; i < imagens.size(); i++)
			{
				final String path = PATH + "/" + imagens.get(i).first;
				
				File imgFile = new File(path);
				if(imgFile.exists())
				{
				    Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
		
				    ImageView myImage = new ImageView(this);
					LinearLayout.LayoutParams ll2 = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
					ll2.setMargins((int) (5*density), (int) (5*density), (int) (5*density), 0);
					myImage.setLayoutParams(ll2);
				    myImage.setImageBitmap(myBitmap);
				    myImage.setAdjustViewBounds(true);
				    myImage.setBackgroundColor(Color.WHITE);
				    myImage.setPadding((int) (5*density), (int) (5*density), (int) (5*density), (int) (5*density));
				    myImage.setOnClickListener(new OnClickListener()
				    {					
						@Override
						public void onClick(View v)
						{
							mostrarImagem(path);
						}
					});
				    layout.addView(myImage);
				    
				    TextView legenda = new TextView(this);
					LinearLayout.LayoutParams ll1 = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
					ll1.setMargins((int) (5*density), 0, (int) (5*density), (int) (5*density));
					legenda.setLayoutParams(ll1);
					legenda.setGravity(Gravity.CENTER_HORIZONTAL);
					legenda.setTextAppearance(this, android.R.style.TextAppearance_Small);
					legenda.setBackgroundColor(Color.WHITE);
					legenda.setTextColor(Color.BLACK);
					legenda.setText(imagens.get(i).second);
					
					layout.addView(legenda);
				}
				else
					Log.e("debug", "Imagem n�o encontrada.");
			}
		}
		
		// epoca voo
		
		ViewGroup epoca_voo_layout = (ViewGroup) findViewById(R.id.epoca_voo);
		
		String voo = dba.getEspecieEpocaVoo(especie);
		
		String[] epoca_voo = decodeEpocaVoo(voo);
		
		float density = this.getResources().getDisplayMetrics().density;
		
		for(int i = 0; i < epoca_voo.length; i++)
		{
			if(epoca_voo[i] != null)
			{
				TextView tv = new TextView(this);
				LinearLayout.LayoutParams tvp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				tvp.setMargins(0, 0, (int) (5*density), 0);
				tv.setLayoutParams(tvp);
				tv.setText(getMes(i));
				tv.setTextAppearance(this, android.R.style.TextAppearance_Medium);
				
				if(epoca_voo[i].equals("low"))
				{
					tv.setTextColor(Color.parseColor("#88FFFFFF"));
				}
				
				epoca_voo_layout.addView(tv);
			}
		}
		
		dba.close();
	}
	
	private String getMes(int mes)
	{
        String[] meses = new String[]{"Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"};
        
        return meses[mes];
	}
	
	private String[] decodeEpocaVoo(String epocaVoo) {
        String[] voo = new String[12];
        String[] temp = epocaVoo.split(":");
        String[] low = new String[0];
        String[] normal = new String[0];
        if(epocaVoo.charAt(0) == ':'){
            normal = temp[1].split("_");
        }else{
            if(epocaVoo.charAt(epocaVoo.length() - 1) == ':'){
                low = temp[0].split("_");
            }else{
                low = temp[0].split("_");
                normal = temp[1].split("_");
            }
        }
        for(String s: low){
            if("JAN".equals(s)){
                voo[0] = "low";
            }
            if("FEV".equals(s)){
                voo[1] = "low";
            }
            if("MAR".equals(s)){
                voo[2] = "low";
            }
            if("ABR".equals(s)){
                voo[3] = "low";
            }
            if("MAI".equals(s)){
                voo[4] = "low";
            }
            if("JUN".equals(s)){
                voo[5] = "low";
            }
            if("JUL".equals(s)){
                voo[6] = "low";
            }
            if("AGO".equals(s)){
                voo[7] = "low";
            }
            if("SET".equals(s)){
                voo[8] = "low";
            }
            if("OUT".equals(s)){
                voo[9] = "low";
            }
            if("NOV".equals(s)){
                voo[10] = "low";
            }
            if("DEZ".equals(s)){
                voo[11] = "low";
            } 
        }
        for(String s: normal){
            if("JAN".equals(s)){
                voo[0] = "normal";
            }
            if("FEV".equals(s)){
                voo[1] = "normal";
            }
            if("MAR".equals(s)){
                voo[2] = "normal";
            }
            if("ABR".equals(s)){
                voo[3] = "normal";
            }
            if("MAI".equals(s)){
                voo[4] = "normal";
            }
            if("JUN".equals(s)){
                voo[5] = "normal";
            }
            if("JUL".equals(s)){
                voo[6] = "normal";
            }
            if("AGO".equals(s)){
                voo[7] = "normal";
            }
            if("SET".equals(s)){
                voo[8] = "normal";
            }
            if("OUT".equals(s)){
                voo[9] = "normal";
            }
            if("NOV".equals(s)){
                voo[10] = "normal";
            }
            if("DEZ".equals(s)){
                voo[11] = "normal";
            } 
        }
        return voo;
    }
	
	public void mostrarImagem(String imagem)
	{
		Intent intent = new Intent(this, ImagemActivity.class);
    	intent.putExtra("path", imagem);
    	startActivity(intent);
	}

	public void goToMapa(View v)
	{
    	Intent intent = new Intent(this, MapaActivity.class);
    	intent.putExtra("especie", especie);
    	startActivity(intent);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ficha, menu);
		return true;
	}

}
