package ualg.les.libapp;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.View;

public class SplashActivity extends Activity
{
	Context context;
	
	private Thread mSplashThread; 
    private boolean mblnClicou = false;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_activity);

		SharedPreferences pref = getApplicationContext().getSharedPreferences("Session", 0); // 0 - for private mode
		Editor editor = pref.edit();
		editor.clear();
		editor.commit();
		
		mSplashThread = new Thread()
		{
			@Override
			public void run()
			{
				try
				{
					synchronized (this)
					{

						wait(2000);
						mblnClicou = true;
					}
				}
				catch (InterruptedException ex)
				{
					
				}

				if (mblnClicou)
				{

					finish();

					Intent i = new Intent();
					i.setClass(SplashActivity.this, MenuActivity.class);
					startActivity(i);
				}
			}
		};

		mSplashThread.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.splash_activity, menu);
        return true;
    }
    
    @Override
    public void onPause()
    {
        super.onPause();

        mSplashThread.interrupt();
    }
    
    public void goToMenu(View view)
    {
    	Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }    
}
