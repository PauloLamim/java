package ualg.les.libapp;

import java.util.List;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.app.FragmentTransaction;

public class FichasEspeciesActivity extends TabActivity 
{

	private ViewGroup layout;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fichas_tab);
		
		TabHost mTabHst = getTabHost();
				
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		List<String> subOrdens = dba.getSubOrdens();
		
		for(String subOrdem : subOrdens)
		{
			// subOrdemHasChilds() 
			
			boolean hasChilds = false;
			
			List<String> f = dba.getFamilias(subOrdem);
			
			for(String familia : f)
			{
				if(!dba.getEspecies(familia).isEmpty())
				{
					hasChilds = true;
					break;
				}
			}
			
			if(hasChilds)
			{
				Intent intent = new Intent(this, SubOrdemActivity.class);
		    	intent.putExtra("subOrdem", subOrdem);
		    	
				mTabHst.addTab(mTabHst.newTabSpec(subOrdem)
						.setIndicator(subOrdem)
						.setContent(intent));
			}
		}
		
		mTabHst.setCurrentTab(0);
		
		dba.close();		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.fichas_especies, menu);
		return true;
	}
}
