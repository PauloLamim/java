package ualg.les.libapp;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.TextView;

public class GPSAdapter extends Service implements LocationListener
{
	private LocationManager lm;
	
	private final Context context; // verificar se � mesmo necessario
	
	private TextView updateView = null;
	
	private AdicionarContributosActivity.Coordenadas coordenadas;
	
	private double latitude = 0.0;
	private double longitude = 0.0;
	
	public GPSAdapter(Context c, AdicionarContributosActivity.Coordenadas coord)
	{
		this.context = c;
		this.coordenadas = coord;
		lm = (LocationManager)c.getSystemService(Context.LOCATION_SERVICE);
		lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 1, this);
	}
	
	public boolean gpsOk()
	{
		return lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
	}
	
	public void stopGPS()
	{
        if(lm != null)
        {
            lm.removeUpdates(GPSAdapter.this);
        }       
    }
	
//	public double getLat()
//	{
//		return latitude;
//	}
//	
//	public double getLon()
//	{
//		return longitude;
//	}
	
	public void setUpdateView(TextView v)
	{
		updateView = v;
	}

	@Override
	public IBinder onBind(Intent intent)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onLocationChanged(Location location)
	{
        latitude = location.getLatitude();  
        longitude = location.getLongitude();
                
//		if(context != null)
//			Toast.makeText(context, "Latitude: " + latitude + " Longitude: " + longitude, Toast.LENGTH_LONG).show();
        
        if(updateView != null)
        	updateView.setText(latitude + ", " + longitude);
        
        coordenadas.setCoordenadas(latitude, longitude);        
	}

	@Override
	public void onProviderDisabled(String arg0)
	{
		if(updateView != null)
        	updateView.setText("GPS desligado!");
	}

	@Override
	public void onProviderEnabled(String provider)
	{
		if(updateView != null)
        	updateView.setText("A obter localiza��o...");
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}
	
}
