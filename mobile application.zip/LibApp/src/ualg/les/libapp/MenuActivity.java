package ualg.les.libapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MenuActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu_activity);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_activity, menu);
		return false; // false n�o mostra o menu
	}
	
    public void goToGuiaCampo(View view) {
    	Intent intent = new Intent(this, GuiaCampoActivity.class);	
        startActivity(intent);
    }

    public void goToIdentificar(View view)
    {
    	Intent intent = new Intent(this, IdentificarActivity.class);
        startActivity(intent);
    }
    
    public void goToFichasEspecie(View view)
    {
    	Intent intent = new Intent(this, FichasEspeciesActivity.class);
        startActivity(intent);
    	
//    	Intent intent = new Intent(this, FichaActivity.class);
//    	intent.putExtra("especie", "Paulo");
//    	startActivity(intent);
    }
    
    public void goToContribuir(View view)
    {
    	//Intent intent = new Intent(this, ContributosActivity.class);
    	Intent intent = new Intent(this, AdicionarContributosActivity.class);
        startActivity(intent);
    }
    
	private boolean isNetworkConnected()
	{
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo ni = cm.getActiveNetworkInfo();
		
		return ni != null;
	}
    
	private EditText user = null;
	private EditText pass = null;
	
	private int autenticarUtilizador(String utilizador, String password)
	{
		StrictMode.enableDefaults(); // por causa do http request 
		
		String result = "";

		try
		{
			ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("username", utilizador));
			nameValuePairs.add(new BasicNameValuePair("password", password));
			
			String url = DBAdapter.url;
			
			HttpParams params = new BasicHttpParams();
		    HttpConnectionParams.setConnectionTimeout(params, 10000);
		    HttpConnectionParams.setSoTimeout(params, 10000);
			
			HttpClient httpclient = new DefaultHttpClient(params);
			HttpPost httppost = new HttpPost(url + "/LibApp/authentication");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
			
			StringBuilder sb = new StringBuilder();
			String line = null;
			
			boolean isContent = false;
			
			while((line = reader.readLine()) != null)
			{
				Log.i("debug", line);
				
				if(line.equals("        <br>marker1<br>"))
				{
					isContent = true;
					continue;
				}
				
				if(line.equals("<br>marker2<br>"))
				{
					isContent = false;
					continue;
				}
				
				if(isContent)
					sb.append(line);
			}

			is.close();
			
			result = sb.toString();
		}
		catch(Exception e)
		{
			Log.e("debug", e.toString());
			return -1;
		}
		
		Log.i("debug", "result: " + result);
		
		return result.equals("ok") ? 1 : 0;
	}
	
	private void autenticar()
	{
		String user_content = user.getText().toString();
		String pass_content = pass.getText().toString();
		
		int result;
		
		if((result = autenticarUtilizador(user_content, pass_content)) == 1)
		{
			SharedPreferences pref = getApplicationContext().getSharedPreferences("Session", 0); // 0 - for private mode
			Editor editor = pref.edit();
			editor.putString("username", user_content);
			editor.commit();
			
			Intent intent = new Intent(this, AtualizarActivity.class);
	    	intent.putExtra("utilizador", user_content);
	    	startActivity(intent);
		}
		else if(result == 0)
		{
			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
			
			alertDialogBuilder.setTitle("Erro!");
			alertDialogBuilder
			.setMessage("Nome de utilizador ou palavra-passe incorretos.\nPor favor, tente de novo.")
			.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int id)
				{					
		            dialog.cancel();
				}
			});
	
			AlertDialog alertDialog = alertDialogBuilder.create();
			alertDialog.show();    	
		}
		else
		{
			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
			
			alertDialogBuilder.setTitle("Erro!");
			alertDialogBuilder
			.setMessage("N�o foi possivel ligar ao servidor.\nPor favor, tente mais tarde.")
			.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int id)
				{					
		            dialog.cancel();
				}
			});
	
			AlertDialog alertDialog = alertDialogBuilder.create();
			alertDialog.show();   
		}
	}
	
    public void update(View view)
    {    	
    	if(isNetworkConnected()) // se tem liga��o � internet
    	{
			SharedPreferences pref = getApplicationContext().getSharedPreferences("Session", 0); // 0 - for private mode
			
			String session_user = pref.getString("username", null);
			
			if(session_user == null)
			{
				LinearLayout layout = new LinearLayout(this);
				LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				layout.setLayoutParams(ll);
				layout.setPadding(5, 5, 5, 5);
				layout.setOrientation(LinearLayout.VERTICAL);
				
		//		TextView tv = new TextView(this);
		//		tv.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		//		tv.setTextAppearance(this, android.R.style.TextAppearance_Medium);
		//		tv.setText("Introduza o seu nome de utilizador e palavra passe.");
		//		
		//		layout.addView(tv);
				
				
				LinearLayout user_layout = new LinearLayout(this);
				user_layout.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
				user_layout.setOrientation(LinearLayout.HORIZONTAL);
				
				TextView user_text = new TextView(this);
				user_text.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
				user_text.setTextAppearance(this, android.R.style.TextAppearance_Medium);
				user_text.setText("Utilizador: ");
				
				user_layout.addView(user_text);
				
				user = new EditText(this);
				user.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
				user.setInputType(InputType.TYPE_CLASS_TEXT);
				
				user_layout.addView(user);
				
				layout.addView(user_layout);
				
				
				LinearLayout pass_layout = new LinearLayout(this);
				pass_layout.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
				pass_layout.setOrientation(LinearLayout.HORIZONTAL);
				
				TextView pass_text = new TextView(this);
				pass_text.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
				pass_text.setTextAppearance(this, android.R.style.TextAppearance_Medium);
				pass_text.setText("Palavra-passe: ");
				
				pass_layout.addView(pass_text);
				
				pass = new EditText(this);
				pass.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
				pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
				
				pass_layout.addView(pass);
				
				layout.addView(pass_layout);
				
				
				AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
		
				alertDialogBuilder.setTitle("Autentica��o");
				alertDialogBuilder
				//.setMessage("User: \nPass:")
				.setView(layout)
				.setCancelable(false)
				.setPositiveButton("Continuar", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
						autenticar();
						
			            dialog.cancel();
					}
				})
				.setNegativeButton("Cancelar", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
			            dialog.cancel();
					}
				});
		
				AlertDialog alertDialog = alertDialogBuilder.create();
				alertDialog.show();
			}
			else
			{
				Intent intent = new Intent(this, AtualizarActivity.class);
		    	intent.putExtra("utilizador", session_user);
		    	startActivity(intent);
			}
		
    	}
    	else // se n�o tem liga��o � internet
    	{
    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

    		alertDialogBuilder.setTitle("Aten��o!");
    		alertDialogBuilder
    		.setMessage("Para atualizar a aplica��o � necess�rio uma liga��o � internet.\nLigue o dispositivo � internet e tente de novo.")
    		.setCancelable(false)
    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
    		{
    			public void onClick(DialogInterface dialog, int id)
    			{    				
    				dialog.cancel();
    			}
    		});

    		AlertDialog alertDialog = alertDialogBuilder.create();
    		alertDialog.show();
    	}
    }
    
    public void goToUpdate(View view)
    {
    	Intent intent = new Intent(this, AtualizarActivity.class);
        startActivity(intent);
    }
}
