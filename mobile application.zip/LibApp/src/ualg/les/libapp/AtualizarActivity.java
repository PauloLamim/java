package ualg.les.libapp;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;

public class AtualizarActivity extends Activity {

	private Context context;
	private String utilizador;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.atualizar_activity);
		
		context = this;
		
		Intent intent = getIntent();
		utilizador = intent.getExtras().getString("utilizador");
		
		Log.i("debug", "utilizador: " + utilizador);
	}
	
	private boolean isNetworkConnected()
	{
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo ni = cm.getActiveNetworkInfo();
		
		return ni != null;
	}
	
	public void atualizarApp(View v)
	{
		if(isNetworkConnected()) // se tem liga��o � internet
    	{
			AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>()
			{
				private ProgressDialog pd;
				private DBAdapter dba;
				
				private boolean state = false;
	
				@Override
				protected void onPreExecute()
				{
					dba = new DBAdapter(context);
					pd = new ProgressDialog(context);
					pd.setTitle("A atualizar...");
					pd.setMessage("Por favor, aguarde.");
					pd.setCancelable(false);
					pd.setIndeterminate(true);
					pd.show();
				}
	
				@Override
				protected Void doInBackground(Void... arg0)
				{
					try
					{
						dba.open();
						state = dba.updateDB();
						dba.close();
	
						Thread.sleep(2000);
					}
					catch (InterruptedException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return null;
				}
	
				@Override
				protected void onPostExecute(Void result)
				{
					pd.dismiss();
					
					if(state)
					{
			    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

			    		//alertDialogBuilder.setTitle("Sucesso!");
			    		alertDialogBuilder
			    		.setMessage("Atualiza��o concluida com exito!")
			    		.setCancelable(false)
			    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
			    		{
			    			public void onClick(DialogInterface dialog, int id)
			    			{    				
			    				dialog.cancel();
			    			}
			    		});

			    		AlertDialog alertDialog = alertDialogBuilder.create();
			    		alertDialog.show();
					}
					else
					{
			    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

			    		//alertDialogBuilder.setTitle("Erro!");
			    		alertDialogBuilder
			    		.setMessage("Ocorreu um erro durante a atualiza��o.\nPor favor, tente novamente.")
			    		.setCancelable(false)
			    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
			    		{
			    			public void onClick(DialogInterface dialog, int id)
			    			{    				
			    				dialog.cancel();
			    			}
			    		});

			    		AlertDialog alertDialog = alertDialogBuilder.create();
			    		alertDialog.show();
					}
				}
			};
			task.execute((Void[]) null);
    	}
		else
		{
    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

    		alertDialogBuilder.setTitle("Aten��o!");
    		alertDialogBuilder
    		.setMessage("Para atualizar a aplica��o � necess�rio uma liga��o � internet.\nLigue o dispositivo � internet e tente de novo.")
    		.setCancelable(false)
    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
    		{
    			public void onClick(DialogInterface dialog, int id)
    			{    				
    				dialog.cancel();
    			}
    		});

    		AlertDialog alertDialog = alertDialogBuilder.create();
    		alertDialog.show();
    	}
	}
	
	public void atualizarImagens(View v)
	{
		if(isNetworkConnected()) // se tem liga��o � internet
    	{
			AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>()
			{
				private ProgressDialog pd;
				private DBAdapter dba;
				
				private boolean state = false;
	
				@Override
				protected void onPreExecute()
				{
					dba = new DBAdapter(context);
					dba.open();
					pd = new ProgressDialog(context);
					pd.setTitle("A atualizar...");
					pd.setMessage("Por favor, aguarde.");
					pd.setCancelable(false);
					pd.setIndeterminate(true);
					pd.show();
				}
	
				@Override
				protected Void doInBackground(Void... arg0)
				{
					try
					{
						state = dba.updateImagens();
	
						Thread.sleep(2000);
					}
					catch (InterruptedException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return null;
				}
	
				@Override
				protected void onPostExecute(Void result)
				{
					dba.close();
					pd.dismiss();
					
					if(state)
					{
			    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

			    		//alertDialogBuilder.setTitle("Sucesso!");
			    		alertDialogBuilder
			    		.setMessage("Atualiza��o concluida com exito!")
			    		.setCancelable(false)
			    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
			    		{
			    			public void onClick(DialogInterface dialog, int id)
			    			{    				
			    				dialog.cancel();
			    			}
			    		});

			    		AlertDialog alertDialog = alertDialogBuilder.create();
			    		alertDialog.show();
					}
					else
					{
			    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

			    		//alertDialogBuilder.setTitle("Erro!");
			    		alertDialogBuilder
			    		.setMessage("Ocorreu um erro durante a atualiza��o.\nPor favor, tente novamente.")
			    		.setCancelable(false)
			    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
			    		{
			    			public void onClick(DialogInterface dialog, int id)
			    			{    				
			    				dialog.cancel();
			    			}
			    		});

			    		AlertDialog alertDialog = alertDialogBuilder.create();
			    		alertDialog.show();
					}
				}
			};
			task.execute((Void[]) null);
    	}
		else
		{
    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

    		alertDialogBuilder.setTitle("Aten��o!");
    		alertDialogBuilder
    		.setMessage("Para atualizar a aplica��o � necess�rio uma liga��o � internet.\nLigue o dispositivo � internet e tente de novo.")
    		.setCancelable(false)
    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
    		{
    			public void onClick(DialogInterface dialog, int id)
    			{    				
    				dialog.cancel();
    			}
    		});

    		AlertDialog alertDialog = alertDialogBuilder.create();
    		alertDialog.show();
    	}
	}
	
	public void enviarContributos(View v)
	{
		if(isNetworkConnected()) // se tem liga��o � internet
    	{
			AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>()
			{
				private ProgressDialog pd;
				private DBAdapter dba;
				
				private boolean state = false;
	
				@Override
				protected void onPreExecute()
				{
					dba = new DBAdapter(context);
					pd = new ProgressDialog(context);
					pd.setTitle("A enviar contributos...");
					pd.setMessage("Por favor, aguarde.");
					pd.setCancelable(false);
					pd.setIndeterminate(true);
					pd.show();
				}
	
				@Override
				protected Void doInBackground(Void... arg0)
				{
					try
					{
						dba.open();
						state = dba.sendContributos(utilizador);
						dba.close();
	
						Thread.sleep(2000);
					}
					catch (InterruptedException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return null;
				}
	
				@Override
				protected void onPostExecute(Void result)
				{
					pd.dismiss();
					
					if(state)
					{
			    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

			    		//alertDialogBuilder.setTitle("Sucesso!");
			    		alertDialogBuilder
			    		.setMessage("Contrubutos enviados com exito!")
			    		.setCancelable(false)
			    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
			    		{
			    			public void onClick(DialogInterface dialog, int id)
			    			{    				
			    				dialog.cancel();
			    			}
			    		});

			    		AlertDialog alertDialog = alertDialogBuilder.create();
			    		alertDialog.show();
					}
					else
					{
			    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

			    		//alertDialogBuilder.setTitle("Erro!");
			    		alertDialogBuilder
			    		.setMessage("Ocorreu um erro durante o envio dos contributos.\nPor favor, tente novamente.")
			    		.setCancelable(false)
			    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
			    		{
			    			public void onClick(DialogInterface dialog, int id)
			    			{    				
			    				dialog.cancel();
			    			}
			    		});

			    		AlertDialog alertDialog = alertDialogBuilder.create();
			    		alertDialog.show();
					}
				}
			};
			task.execute((Void[]) null);
    	}
		else
		{
    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

    		alertDialogBuilder.setTitle("Aten��o!");
    		alertDialogBuilder
    		.setMessage("Para atualizar a aplica��o � necess�rio uma liga��o � internet.\nLigue o dispositivo � internet e tente de novo.")
    		.setCancelable(false)
    		.setNeutralButton("Fechar", new DialogInterface.OnClickListener()
    		{
    			public void onClick(DialogInterface dialog, int id)
    			{    				
    				dialog.cancel();
    			}
    		});

    		AlertDialog alertDialog = alertDialogBuilder.create();
    		alertDialog.show();
    	}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.atualizar, menu);
		return true;
	}

}
