package ualg.les.libapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper
{
	private static final String DATABASE_NAME = "libapp.db";
	private static final int DATABASE_VERSION = 18;

	private static final String atributos_familia = "CREATE TABLE 'atributos_familia' ( 'idatributos_familia' INTEGER, 'nome' TEXT, 'descricao' TEXT );";
	private static final String atributos_sub_ordem = "CREATE TABLE 'atributos_sub_ordem' ( 'idatributos_sub_ordem' INTEGER, 'nome' TEXT, 'descricao' TEXT );";
	private static final String contributos = "CREATE TABLE 'contributos' ( 'idcontributos' INTEGER, 'longitude' TEXT, 'latitude' TEXT, 'nome_local' TEXT, 'data' TEXT, 'observacoes' TEXT, 'estado_contributo_nome' VARCHAR, 'estadio_ciclo_vida_nome' VARCHAR, 'utilizadores_nome_utilizador' VARCHAR, 'especie_nome' VARCHAR, 'classes_dimensao_nome' VARCHAR );";
	private static final String contributos_android = "CREATE TABLE 'contributos_android' ( 'idcontributos' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, 'longitude' TEXT, 'latitude' TEXT, 'nome_local' TEXT, 'data' TEXT, 'observacoes' TEXT, 'estado_contributo_nome' VARCHAR, 'estadio_ciclo_vida_nome' VARCHAR, 'utilizadores_nome_utilizador' VARCHAR, 'especie_nome' VARCHAR, 'classes_dimensao_nome' VARCHAR );";
	private static final String especie = "CREATE TABLE 'especie' ( 'nome' VARCHAR, 'nome_ingles' TEXT, 'tendencia' TEXT, 'descobridor' TEXT, 'ano_descoberta' INTEGER, 'estatuto_conservacao' TEXT, 'epoca_voo' TEXT, 'identificacao' TEXT, 'outras_informacoes' TEXT, 'fontes_informacao' TEXT, 'familia_nome' VARCHAR );";
	private static final String especie_has_habitats = "CREATE TABLE 'especie_has_habitats' ( 'especie_nome' VARCHAR, 'habitats_idhabitats' INTEGER );";
	private static final String estadio_ciclo_vida = "CREATE TABLE 'estadio_ciclo_vida' ( 'nome' VARCHAR, 'descricao' TEXT );";
	private static final String classes_dimensao = "CREATE TABLE 'classes_dimensao' ( 'nome' VARCHAR, 'descricao' TEXT );";
	private static final String estado_contributo = "CREATE TABLE 'estado_contributo' ( 'nome' VARCHAR, 'descricao' TEXT );";
	private static final String familia = "CREATE TABLE 'familia' ( 'nome' VARCHAR, 'descricao' TEXT, 'sub_ordem_nome' VARCHAR );";
	private static final String familia_has_atributos_familia = "CREATE TABLE 'familia_has_atributos_familia' ( 'familia_nome' VARCHAR, 'atributos_familia_idatributos_familia' INTEGER );";
	private static final String habitats = "CREATE TABLE 'habitats' ( 'idhabitats' INTEGER, 'descricao' TEXT, 'subtipos_habitats_idsubtipos_habitats' INTEGER );";
	private static final String imagens = "CREATE TABLE 'imagens' ( 'idimagens' INTEGER, 'nome' TEXT, 'path' TEXT, 'legenda' TEXT, 'especie_nome' VARCHAR );";
	private static final String ordem = "CREATE TABLE 'ordem' ( 'nome' VARCHAR, 'descricao' TEXT );";
	private static final String sub_ordem = "CREATE TABLE 'sub_ordem' ( 'nome' VARCHAR, 'descricao' TEXT, 'ordem_nome' VARCHAR );";
	private static final String sub_ordem_has_atributos_sub_ordem = "CREATE TABLE 'sub_ordem_has_atributos_sub_ordem' ( 'sub_ordem_nome' VARCHAR, 'atributos_sub_ordem_idatributos_sub_ordem' INTEGER );";
	private static final String subtipos_habitats = "CREATE TABLE 'subtipos_habitats' ( 'idsubtipos_habitats' INTEGER, 'descricao' TEXT, 'tipos_habitats_idtipos_habitats' INTEGER );";
	private static final String textos_introdutorios = "CREATE TABLE 'textos_introdutorios' ( 'idtextos_introdutorios' INTEGER, 'nome' VARCHAR, 'texto' TEXT, 'utilizadores_nome_utilizador' VARCHAR );";
	private static final String tipos_habitats = "CREATE TABLE 'tipos_habitats' ( 'idtipos_habitats' INTEGER, 'descricao' TEXT );";
	
	public DBHelper(Context context)
	{
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase database)
	{
		try
		{
			database.execSQL(atributos_familia);
			database.execSQL(atributos_sub_ordem);
			database.execSQL(contributos);
			database.execSQL(contributos_android);
			database.execSQL(especie);
			database.execSQL(especie_has_habitats);
			database.execSQL(estadio_ciclo_vida);
			database.execSQL(classes_dimensao);
			database.execSQL(estado_contributo);
			database.execSQL(familia);
			database.execSQL(familia_has_atributos_familia);
			database.execSQL(habitats);
			database.execSQL(imagens);
			database.execSQL(ordem);
			database.execSQL(sub_ordem);
			database.execSQL(sub_ordem_has_atributos_sub_ordem);
			database.execSQL(subtipos_habitats);
			database.execSQL(textos_introdutorios);
			database.execSQL(tipos_habitats);
		}
		catch (Exception e)
		{
			Log.e("debug", "onCreate(): " + e.toString());
		}
	}

	@Override
	public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion)
	{
		try
		{
			database.execSQL("DROP TABLE IF EXISTS atributos_familia;");
			database.execSQL("DROP TABLE IF EXISTS atributos_sub_ordem;");
			database.execSQL("DROP TABLE IF EXISTS contributos;");
			database.execSQL("DROP TABLE IF EXISTS contributos_android;");
			database.execSQL("DROP TABLE IF EXISTS especie;");
			database.execSQL("DROP TABLE IF EXISTS especie_has_habitats;");
			database.execSQL("DROP TABLE IF EXISTS estadio_ciclo_vida;");
			database.execSQL("DROP TABLE IF EXISTS classes_dimensao;");
			database.execSQL("DROP TABLE IF EXISTS estado_contributo;");
			database.execSQL("DROP TABLE IF EXISTS familia;");
			database.execSQL("DROP TABLE IF EXISTS familia_has_atributos_familia;");
			database.execSQL("DROP TABLE IF EXISTS habitats;");
			database.execSQL("DROP TABLE IF EXISTS imagens;");
			database.execSQL("DROP TABLE IF EXISTS ordem;");
			database.execSQL("DROP TABLE IF EXISTS sub_ordem;");
			database.execSQL("DROP TABLE IF EXISTS sub_ordem_has_atributos_sub_ordem;");
			database.execSQL("DROP TABLE IF EXISTS subtipos_habitats;");
			database.execSQL("DROP TABLE IF EXISTS textos_introdutorios;");
			database.execSQL("DROP TABLE IF EXISTS tipos_habitats;");
		}
		catch (Exception e)
		{
			Log.e("debug", "onUpgrade(): " + e.toString());
		}
		
		onCreate(database);
	}
}
