package ualg.les.libapp;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Pair;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

public class IdentificarResultadosActivity extends Activity {
	
	private List<Pair<View, String>> view_especies = new ArrayList<Pair<View, String>>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.identificar_resultados_activity);
		
		float density = this.getResources().getDisplayMetrics().density;
		
		Intent intent = getIntent();
		ArrayList<String> especies = intent.getExtras().getStringArrayList("especies");
		
		ViewGroup layout = (ViewGroup) findViewById(R.id.resultados);
		
		if(especies.isEmpty())
		{
			TextView tv = new TextView(this);
			LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
			lp.setMargins(0, 100, 0, 0);
			tv.setLayoutParams(lp);
			tv.setTextAppearance(this, android.R.style.TextAppearance_Medium);
			tv.setText("N�o foi encontrada nenhuma especie com as caracteristicas introduzidas.");
			tv.setGravity(Gravity.CENTER);
			tv.setBackgroundResource(R.drawable.btn_default);
			tv.setPadding((int) (10*density), (int) (5*density), (int) (10*density), (int) (5*density));
			layout.addView(tv);
			
			
		}
		else
		{
			int k = 1;
			for(String especie : especies)
			{
				TextView tv = new TextView(this);
				LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
				lp.setMargins(0, 0, 0, (int) (5*density));
				tv.setLayoutParams(lp);
				tv.setTextAppearance(this, android.R.style.TextAppearance_Large);
				SpannableString spanString = new SpannableString(especie);
				spanString.setSpan(new UnderlineSpan(), 0, spanString.length(), 0);
				tv.setText(k + "�  " + spanString);
				tv.setOnClickListener(new OnClickListener()
				{	
					@Override
					public void onClick(View v)
					{
						goToFicha(v);
					}
				});
				
				tv.setBackgroundResource(R.drawable.btn_back);
				tv.setPadding((int) (10*density), (int) (5*density), (int) (10*density), (int) (5*density));
				tv.setGravity(Gravity.CENTER_VERTICAL);
				
				view_especies.add(new Pair<View, String>(tv, especie));
				
				layout.addView(tv);
				k++;
			}
		}
	}

	public void goToFicha(View v)
	{
		for(Pair<View, String> p : view_especies)
		{
			if(v == p.first)
			{
				Intent intent = new Intent(this, FichaActivity.class);
		    	intent.putExtra("especie", p.second);
		    	startActivity(intent);
			}
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.identificar_resultados, menu);
		return true;
	}

}
