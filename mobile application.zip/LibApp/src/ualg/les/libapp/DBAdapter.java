package ualg.les.libapp;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.ByteArrayBuffer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.StrictMode;
import android.util.Log;
import android.util.Pair;

public class DBAdapter
{
	private SQLiteDatabase database;
	private DBHelper dbHelper;

	private Context context;
	
	public static String url = "http://10.10.22.169:8090";
	
	public DBAdapter(Context context)
	{
		dbHelper = new DBHelper(context);
		this.context = context;
	}

	public void open() throws SQLException
	{
		database = dbHelper.getWritableDatabase();
	}

	public void close()
	{
		dbHelper.close();
	}

	private String getTableJSON(String table)
	{
		StrictMode.enableDefaults(); // por causa do http request
		
		String result = "";

		try
		{
			ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("tabela", table));
			
			HttpParams params = new BasicHttpParams();
		    HttpConnectionParams.setConnectionTimeout(params, 10000);
		    HttpConnectionParams.setSoTimeout(params, 10000);
			
			HttpClient httpclient = new DefaultHttpClient(params);
			HttpPost httppost = new HttpPost(url + "/LibApp/update");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
			
			StringBuilder sb = new StringBuilder();
			String line = null;
			
			boolean isContent = false;
			
			while((line = reader.readLine()) != null)
			{
				if(line.equals("        <br>marker1<br>"))
				{
					isContent = true;
					continue;
				}
				
				if(line.equals("<br>marker2<br>"))
				{
					isContent = false;
					continue;
				}
				
				if(isContent)
					sb.append(line + "\n");
			}

			is.close();
			
			result = sb.toString();
		}
		catch(Exception e)
		{
			Log.e("debug", e.toString());
			return "LibAppError";
		}
		
		return result;
	}
	
	public boolean updateDB()
	{
		List<String> tables = new ArrayList<String>();
		
		tables.add("atributos_familia");
		tables.add("atributos_sub_ordem");
		tables.add("contributos");
		tables.add("especie");
		tables.add("especie_has_habitats");
		tables.add("estadio_ciclo_vida");
		tables.add("classes_dimensao");
		tables.add("estado_contributo");
		tables.add("familia");
		tables.add("familia_has_atributos_familia");
		tables.add("habitats");
		tables.add("imagens");
		tables.add("ordem");
		tables.add("sub_ordem");
		tables.add("sub_ordem_has_atributos_sub_ordem");
		tables.add("subtipos_habitats");
		tables.add("textos_introdutorios");
		tables.add("tipos_habitats");
		
		for(String table : tables)
		{
			Log.i("debug", "->" + table);
			
			String json_string = getTableJSON(table);
			
			Log.i("debug", json_string);
			
			if(json_string.equals(""))
				continue;
			else if(json_string.equals("LibAppError"))
				return false;
			
			database.execSQL("DELETE FROM "+ table +";");
			
			try
			{
				JSONArray jArray = new JSONArray(json_string);
				
				for(int i = 0; i < jArray.length(); i++)
				{
					JSONObject json_data = jArray.getJSONObject(i);
					
					JSONArray table_names = json_data.names();
					
					ContentValues values = new ContentValues(); // sqlite
					
					for(int j = 0; j < table_names.length(); j++)
					{
						String table_name = table_names.getString(j);
						
						//Log.i("debug", table_name + ": " + json_data.getString(table_name));
						
						values.put(table_name, json_data.getString(table_name));
					}
					
					if(database.insert(table, null, values) == -1)
					{
						Log.e("debug", "updateDB() erro");
						return false;
					}
				}
			}
			catch(JSONException e)
			{
				Log.e("debug", "Error parsing data "+e.toString());
				return false;
			}
		}
		
		return true;
	}
	
	public List<String> getTeste(String especie, String mes)
	{	
		List<String> teste = new ArrayList<String>();
		
		//Cursor cursor = database.query("especie", new String[]{"nome"}, null, null, null, null, null);
		//Cursor cursor = database.rawQuery("SELECT * FROM sqlite_master WHERE type='table';", null);
		
		Cursor cursor = database.rawQuery("SELECT e.nome FROM especie e WHERE e.nome = ? AND e.epoca_voo LIKE ?", new String[]{especie, "%"+mes+"%"});
		
		Log.i("debug", ""+(cursor != null && cursor.getCount() > 0));
		
		cursor.moveToFirst();
		while (!cursor.isAfterLast())
		{
			teste.add(cursor.getString(0));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
		
	public List<String> getEspecies()
	{
		List<String> teste = new ArrayList<String>();
		
		Cursor cursor = database.query("especie", new String[]{"nome"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(cursor.getString(0));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public List<Pair<String, String>> getEstadios()
	{
		List<Pair<String, String>> teste = new ArrayList<Pair<String, String>>();
		
		Cursor cursor = database.query("estadio_ciclo_vida", new String[]{"nome", "descricao"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(new Pair<String, String>(cursor.getString(0), cursor.getString(1)));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public List<Pair<String, String>> getExemplares()
	{
		List<Pair<String, String>> teste = new ArrayList<Pair<String, String>>();
		
		Cursor cursor = database.query("classes_dimensao", new String[]{"nome", "descricao"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(new Pair<String, String>(cursor.getString(0), cursor.getString(1)));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}

	public List<String> getHabitats()
	{
		List<String> teste = new ArrayList<String>();
		
		Cursor cursor = database.query("habitats", new String[]{"descricao"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(cursor.getString(0));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public boolean especieHasAtribute(String especie, String nome, String descricao)
	{
		Cursor cursor = database.rawQuery("SELECT e.nome FROM especie e, familia f, familia_has_atributos_familia fha, atributos_familia af, sub_ordem so, sub_ordem_has_atributos_sub_ordem soha, atributos_sub_ordem aso WHERE e.nome = ? AND e.familia_nome = f.nome AND f.sub_ordem_nome = so.nome AND fha.familia_nome = f.nome AND fha.atributos_familia_idatributos_familia = af.idatributos_familia AND soha.sub_ordem_nome = so.nome AND soha.atributos_sub_ordem_idatributos_sub_ordem = aso.idatributos_sub_ordem AND ((af.nome = ? AND af.descricao = ?) OR (aso.nome = ? AND aso.descricao = ?))", new String[]{especie, nome, descricao, nome, descricao});
		return cursor != null && cursor.getCount() > 0;
	}
	
	public boolean especieHasHabitat(String especie, String habitat)
	{
		Cursor cursor = database.rawQuery("SELECT e.nome FROM especie e, especie_has_habitats ehh, habitats h WHERE e.nome = ? AND e.nome = ehh.especie_nome AND ehh.habitats_idhabitats = h.idhabitats AND h.descricao = ?", new String[]{especie, habitat});
		return cursor != null && cursor.getCount() > 0;
	}
	
	public boolean especieHasEpocaVoo(String especie, String mes)
	{
		Cursor cursor = database.rawQuery("SELECT e.nome FROM especie e WHERE e.nome = ? AND e.epoca_voo LIKE ?", new String[]{especie, "%"+mes+"%"});
		return cursor != null && cursor.getCount() > 0;
	}
	
	public int createContributo(double lat, double lon, String especie, String estadio, String exemplares, String observacoes, String data)
	{
		ContentValues values = new ContentValues();
		values.put("longitude", lon);
		values.put("latitude", lat);
		values.put("data", data);
		values.put("observacoes", observacoes);
		values.put("estado_contributo_nome", "a aguardar submiss�o");
		values.put("estadio_ciclo_vida_nome", estadio);
		values.put("especie_nome", especie);
		values.put("classes_dimensao_nome", exemplares);
		
		return (int) database.insert("contributos_android", null, values);
	}
	
	public List<Integer> getContributosID()
	{
		List<Integer> teste = new ArrayList<Integer>();
		
		Cursor cursor = database.query("contributos_android", new String[]{"idcontributos"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(cursor.getInt(0));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public String getContributoEspecie(int id)
	{
		String nome = "";
		
		Cursor cursor = database.rawQuery("SELECT especie_nome FROM contributos_android WHERE idcontributos = ?;",  new String[]{id+""});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			nome = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return nome;
	}
	
	public String getContributoData(int id)
	{
		String data = "";
		
		Cursor cursor = database.rawQuery("SELECT data FROM contributos_android WHERE idcontributos = ?;",  new String[]{id+""});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			data = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return data;
	}

	public List<Pair<String, String>> getAtributosSO()
	{
		List<Pair<String, String>> teste = new ArrayList<Pair<String, String>>();
		
		Cursor cursor = database.query("atributos_sub_ordem", new String[]{"nome", "descricao"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(new Pair<String, String>(cursor.getString(0), cursor.getString(1)));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public List<Pair<String, String>> getAtributosF()
	{
		List<Pair<String, String>> teste = new ArrayList<Pair<String, String>>();
		
		Cursor cursor = database.query("atributos_familia", new String[]{"nome", "descricao"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(new Pair<String, String>(cursor.getString(0), cursor.getString(1)));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}

	private boolean postContributo(List<Pair<String, String>> contributo)
	{
		StrictMode.enableDefaults(); // por causa do http request
		
		try
		{
			ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			
			for(Pair<String, String> p : contributo)
				nameValuePairs.add(new BasicNameValuePair(p.first, p.second));
						
			
			HttpParams params = new BasicHttpParams();
		    HttpConnectionParams.setConnectionTimeout(params, 10000);
		    HttpConnectionParams.setSoTimeout(params, 10000);
		    
			HttpClient httpclient = new DefaultHttpClient(params);
			HttpPost httppost = new HttpPost(url + "/LibApp/submeter_contributos");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
		}
		catch(Exception e)
		{
			Log.e("debug", e.toString());
			return false;
		}
		
		return true;
	}
	
	public Cursor getContributos()
	{
		Cursor cursor = database.query("contributos_android", /*(String[]) tables.toArray()*/ null, null, null, null, null, null);
		
		return cursor;
	}
	
	public boolean sendContributos(String utilizador)
	{				
		Cursor contributos = getContributos();
		
		contributos.moveToFirst();
		while(!contributos.isAfterLast())
		{
			int idcontributos = 0;
			
			List<Pair<String, String>> contributo = new ArrayList<Pair<String, String>>();
			
			int count = contributos.getColumnCount();
			
			for(int i = 0; i < count; i++)
			{
				String nome = contributos.getColumnName(i);
				String conteudo = contributos.getString(i);
				
				if(nome.equals("idcontributos"))
					idcontributos = Integer.parseInt(conteudo);
				
				if(nome.equals("utilizadores_nome_utilizador"))
					conteudo = utilizador;
								
				contributo.add(new Pair<String, String>(nome, conteudo));
			}
			
			if(postContributo(contributo))
				database.execSQL("DELETE FROM contributos_android WHERE idcontributos = " + idcontributos + ";");
			else
				return false;
			
			for(Pair<String, String> p : contributo)
				Log.i("debug", p.first + " - " + p.second);
			
			Log.i("debug", "---");
			
			contributos.moveToNext();
		}
		contributos.close();
		
		return true;
	}
	
	public List<Pair<String, String>> getTextos()
	{
		List<Pair<String, String>> teste = new ArrayList<Pair<String, String>>();
		
		Cursor cursor = database.query("textos_introdutorios", new String[]{"nome", "texto"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(new Pair<String, String>(cursor.getString(0), cursor.getString(1)));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		for(Pair<String, String> p : teste)
			Log.i("debug", p.first + " - " + p.second);
		
		return teste;
	}
	
	private boolean downloadFromUrl(String imageURL, String fileName)
	{
		//StrictMode.enableDefaults();
		
		String PATH = context.getFilesDir().getPath();

		try
		{
			URL url = new URL(imageURL + fileName);
			File file = new File(PATH + "/" + fileName);
			
			URLConnection ucon = url.openConnection();
			ucon.setConnectTimeout(10 * 1000);

			InputStream is = ucon.getInputStream();
			BufferedInputStream bis = new BufferedInputStream(is);

			ByteArrayBuffer baf = new ByteArrayBuffer(50);
			int current = 0;
			while ((current = bis.read()) != -1)
			{
				baf.append((byte) current);
			}

			FileOutputStream fos = new FileOutputStream(file);
			fos.write(baf.toByteArray());
			fos.close();

		}
		catch (IOException e)
		{
			Log.d("debug", "Erro: " + e);
			return false;
		}
		
		return true;
	}
    
    public boolean updateImagens()
    {		
		Cursor cursor = database.query("imagens", new String[]{"nome", "path"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			String path = cursor.getString(1);
			String nome = cursor.getString(0);
			
			if(!downloadFromUrl(url + "/LibApp/" + path, nome))
				return false;
			
			Log.i("debug", path + nome);
			
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return true;
    }
    
    public List<String> getSubOrdens()
    {
		List<String> teste = new ArrayList<String>();
		
		Cursor cursor = database.query("sub_ordem", new String[]{"nome"}, null, null, null, null, null);
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(cursor.getString(0));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
    }

	public List<String> getFamilias(String subOrdem)
    {
		List<String> teste = new ArrayList<String>();
		
		Cursor cursor = database.rawQuery("SELECT nome FROM familia WHERE sub_ordem_nome = ?;",  new String[]{subOrdem});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(cursor.getString(0));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
    }
	
	public List<String> getEspecies(String familia)
	{
		List<String> teste = new ArrayList<String>();
		
		Cursor cursor = database.rawQuery("SELECT nome FROM especie WHERE familia_nome = ?;",  new String[]{familia});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(cursor.getString(0));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public String getEspecieDescoberta(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT descobridor, ano_descoberta FROM especie WHERE nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0) + ", " + cursor.getString(1);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public String getEspecieIngles(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT nome_ingles FROM especie WHERE nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public String getEspecieSubOrdem(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT f.sub_ordem_nome FROM especie e, familia f WHERE e.familia_nome = f.nome AND e.nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public String getEspecieFamilia(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT familia_nome FROM especie WHERE nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public String getEspecieEstatuto(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT estatuto_conservacao FROM especie WHERE nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public String getEspecieTendencia(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT tendencia FROM especie WHERE nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public List<Pair<String, String>> getEspecieHabitats(String especie)
	{
		List<Pair<String, String>> result = new ArrayList<Pair<String,String>>();
		
		Cursor cursor = database.rawQuery("SELECT sh.descricao, h.descricao FROM especie e, especie_has_habitats ehh, habitats h, subtipos_habitats sh WHERE ehh.especie_nome = e.nome AND ehh.habitats_idhabitats = h.idhabitats AND h.subtipos_habitats_idsubtipos_habitats = sh.idsubtipos_habitats AND e.nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			result.add(new Pair<String, String>(cursor.getString(0), cursor.getString(1)));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return result;
	}
	
	public String getEspecieIdentificacao(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT identificacao FROM especie WHERE nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public String getEspecieInfo(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT outras_informacoes FROM especie WHERE nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public List<Pair<String, String>> getImagens(String especie)
	{
		List<Pair<String, String>> teste = new ArrayList<Pair<String, String>>();
		
		Cursor cursor = database.rawQuery("SELECT nome, legenda FROM imagens WHERE especie_nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(new Pair<String, String>(cursor.getString(0), cursor.getString(1)));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
	
	public List<Pair<Double, Double>> getCoordenadas(String especie)
	{
		List<Pair<Double, Double>> teste = new ArrayList<Pair<Double, Double>>();
		
		Cursor cursor = database.rawQuery("SELECT latitude, longitude FROM contributos WHERE especie_nome = ? AND estado_contributo_nome = ?;",  new String[]{especie, "aceite"});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste.add(new Pair<Double, Double>(Double.parseDouble(cursor.getString(0)), Double.parseDouble(cursor.getString(1))));
			cursor.moveToNext();
		}
		
		cursor.close();
		
		for(Pair<Double, Double> p : teste)
			Log.i("debug", p.first + " - " + p.second);
		
		return teste;
	}

	public String getEspecieEpocaVoo(String especie)
	{
		String teste = "";
		
		Cursor cursor = database.rawQuery("SELECT epoca_voo FROM especie WHERE nome = ?;",  new String[]{especie});
		
		cursor.moveToFirst();
		while(!cursor.isAfterLast())
		{
			teste = cursor.getString(0);
			cursor.moveToNext();
		}
		
		cursor.close();
		
		return teste;
	}
}