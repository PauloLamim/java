package ualg.les.libapp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.util.Pair;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class IdentificarActivity extends Activity
{
	private int countTipo(List<Pair<String, String>> list, String atributo)
	{
		int result = 0;
		
		for(Pair<String, String> l : list)
		{
			if(l.first.equals(atributo))
				result++;
		}
		
		return result;
	}
	
	// SubOrdem
	
	private List<Pair<View, Pair<String, String>>> viewsSubOrdem = new ArrayList<Pair<View,Pair<String,String>>>(); // (view, (tipo, descri��o))
	private List<Pair<String, String>> filtroSubOrdem = new ArrayList<Pair<String,String>>();
	
	private void criarIdentificarSubOrdem()
	{
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		List<Pair<String, String>> atributos_so = dba.getAtributosSO();
		
		dba.close();
		
		ViewGroup layout = (ViewGroup) findViewById(R.id.identificar_subordem);
		
		for(int i = 0; i < atributos_so.size(); i++)
		{
			String tipo = atributos_so.get(i).first; // TextView titulo
			
			LinearLayout wraper = new LinearLayout(this);
			wraper.setOrientation(LinearLayout.VERTICAL);
			
			float density = this.getResources().getDisplayMetrics().density;
			
			wraper.setBackgroundResource(R.drawable.btn_default);
			wraper.setPadding((int) (15*density), (int) (10*density), (int) (15*density), (int) (10*density));
			
			TextView tv = new TextView(this);
			tv.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
			tv.setTextAppearance(this, android.R.style.TextAppearance_Large);
			tv.setText(tipo);
			wraper.addView(tv);
			
			if(countTipo(atributos_so, tipo) == 2)
			{
				RadioGroup rg = new RadioGroup(this);
				
				int j = Integer.valueOf(i);
				
				while(j < atributos_so.size())
				{
					if(atributos_so.get(j).first.equals(tipo))
					{
						String descricao = atributos_so.get(j).second;
											
						RadioButton rb = new RadioButton(this);
						rb.setLayoutParams(new RadioGroup.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
						rb.setTextAppearance(this, android.R.style.TextAppearance_Medium);
						rb.setText(descricao);
						rb.setOnClickListener(new OnClickListener()
						{	
							@Override
							public void onClick(View v)
							{
								onClickSubOrdemRadioButton(v);
							}
						});
											
						viewsSubOrdem.add(new Pair<View, Pair<String, String>>(rb, new Pair<String, String>(tipo, descricao))); // (view, (tipo, descri��o))
						
						rg.addView(rb);
						
						atributos_so.remove(j);
						
						continue;
					}
					
					j++;
				}
				
				i--;
				
				wraper.addView(rg);
				
				layout.addView(wraper);
			}
			else
			{
				int j = Integer.valueOf(i);
				
				while(j < atributos_so.size())
				{
					if(atributos_so.get(j).first.equals(tipo))
					{
						String descricao = atributos_so.get(j).second;
											
						CheckBox cb = new CheckBox(this);
						cb.setLayoutParams(new RadioGroup.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
						cb.setTextAppearance(this, android.R.style.TextAppearance_Medium);
						cb.setText(descricao);
						cb.setOnClickListener(new OnClickListener()
						{	
							@Override
							public void onClick(View v)
							{
								onClickSubOrdemCheckBox(v);
							}
						});
											
						viewsSubOrdem.add(new Pair<View, Pair<String, String>>(cb, new Pair<String, String>(tipo, descricao))); // (view, (tipo, descri��o))
						
						wraper.addView(cb);
						
						atributos_so.remove(j);
						
						continue;
					}
					
					j++;
				}
				
				i--;
								
				layout.addView(wraper);
			}			
		}
	}
	
	public void addFiltroSubOrdemRadioButton(Pair<String, String> filtro)
	{
		for(int i = 0; i < filtroSubOrdem.size(); i++) // se existe substitui e retorna
		{
			if(filtroSubOrdem.get(i).first == filtro.first)
			{
				filtroSubOrdem.set(i, filtro);
				return;
			}
		}
		
		filtroSubOrdem.add(filtro); // se chegou aqui � porque n�o existe e basta adicionar
	}
	
	public boolean isRadioButtonCheckedSubOrdem(View v, Pair<String, String> filtro)
	{
		for(int i = 0; i < filtroSubOrdem.size(); i++)
		{
			if(filtroSubOrdem.get(i).first == filtro.first && filtroSubOrdem.get(i).second == filtro.second)
			{
				filtroSubOrdem.remove(i);
				
				((RadioGroup)v.getParent()).clearCheck();
				return true;
			}
		}
		
		return false;
	}
	
	public void onClickSubOrdemRadioButton(View v)
	{
		for(Pair<View, Pair<String, String>> p : viewsSubOrdem)
		{
			if(p.first == v)
			{
				if(isRadioButtonCheckedSubOrdem(v, p.second))
					continue;
				
				addFiltroSubOrdemRadioButton(p.second);
			}
		}
	}
	
	public void addFiltroSubOrdemCheckBox(Pair<String, String> filtro)
	{
		for(int i = 0; i < filtroSubOrdem.size(); i++) // se existe remove e retorna
		{
			if(filtroSubOrdem.get(i).first == filtro.first && filtroSubOrdem.get(i).second == filtro.second)
			{
				filtroSubOrdem.remove(i);
				return;
			}
		}
		
		filtroSubOrdem.add(filtro); // se chegou aqui � porque n�o existe e basta adicionar
	}
	
	public void onClickSubOrdemCheckBox(View v)
	{
		for(Pair<View, Pair<String, String>> p : viewsSubOrdem)
		{
			if(p.first == v)
			{
				addFiltroSubOrdemCheckBox(p.second);
			}
		}
	}
	
	// Familia
	
	private List<Pair<View, Pair<String, String>>> viewsFamilia = new ArrayList<Pair<View,Pair<String,String>>>(); // (view, (tipo, descri��o))
	private List<Pair<String, String>> filtroFamilia = new ArrayList<Pair<String,String>>();
	
	private void criarIdentificarFamilia()
	{
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		List<Pair<String, String>> atributos_f = dba.getAtributosF();
		
		dba.close();
		
		ViewGroup layout = (ViewGroup) findViewById(R.id.identificar_familia);
		
		for(int i = 0; i < atributos_f.size(); i++)
		{
			String tipo = atributos_f.get(i).first; // TextView titulo
			
			LinearLayout wraper = new LinearLayout(this);
			wraper.setOrientation(LinearLayout.VERTICAL);
			
			float density = this.getResources().getDisplayMetrics().density;
			
			wraper.setBackgroundResource(R.drawable.btn_default);
			wraper.setPadding((int) (15*density), (int) (10*density), (int) (15*density), (int) (10*density));
			
			TextView tv = new TextView(this);
			tv.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
			tv.setTextAppearance(this, android.R.style.TextAppearance_Large);
			tv.setText(tipo);
			wraper.addView(tv);
			
			if(countTipo(atributos_f, tipo) == 2)
			{
				RadioGroup rg = new RadioGroup(this);
				
				int j = Integer.valueOf(i);
				
				while(j < atributos_f.size())
				{
					if(atributos_f.get(j).first.equals(tipo))
					{
						String descricao = atributos_f.get(j).second;
											
						RadioButton rb = new RadioButton(this);
						rb.setLayoutParams(new RadioGroup.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
						rb.setTextAppearance(this, android.R.style.TextAppearance_Medium);
						rb.setText(descricao);
						rb.setOnClickListener(new OnClickListener()
						{	
							@Override
							public void onClick(View v)
							{
								onClickFamiliaRadioButton(v);
							}
						});
											
						viewsFamilia.add(new Pair<View, Pair<String, String>>(rb, new Pair<String, String>(tipo, descricao))); // (view, (tipo, descri��o))
						
						rg.addView(rb);
						
						atributos_f.remove(j);
						
						continue;
					}
					
					j++;
				}
				
				i--;
				
				wraper.addView(rg);
				
				layout.addView(wraper);
			}
			else
			{								
				int j = Integer.valueOf(i);
				
				while(j < atributos_f.size())
				{
					if(atributos_f.get(j).first.equals(tipo))
					{
						String descricao = atributos_f.get(j).second;
											
						CheckBox cb = new CheckBox(this);
						cb.setLayoutParams(new RadioGroup.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
						cb.setTextAppearance(this, android.R.style.TextAppearance_Medium);
						cb.setText(descricao);
						cb.setOnClickListener(new OnClickListener()
						{	
							@Override
							public void onClick(View v)
							{
								onClickFamiliaCheckBox(v);
							}
						});
											
						viewsFamilia.add(new Pair<View, Pair<String, String>>(cb, new Pair<String, String>(tipo, descricao))); // (view, (tipo, descri��o))
						
						wraper.addView(cb);
						
						atributos_f.remove(j);
						
						continue;
					}
					
					j++;
				}
				
				i--;
				
				layout.addView(wraper);
			}			
		}
	}
	
	public void addFiltroFamiliaRadioButton(Pair<String, String> filtro)
	{
		for(int i = 0; i < filtroFamilia.size(); i++) // se existe substitui e retorna
		{
			if(filtroFamilia.get(i).first == filtro.first)
			{
				filtroFamilia.set(i, filtro);
				return;
			}
		}
		
		filtroFamilia.add(filtro); // se chegou aqui � porque n�o existe e basta adicionar
	}
	
	public boolean isRadioButtonCheckedFamilia(View v, Pair<String, String> filtro)
	{
		for(int i = 0; i < filtroFamilia.size(); i++)
		{
			if(filtroFamilia.get(i).first == filtro.first && filtroFamilia.get(i).second == filtro.second)
			{
				filtroFamilia.remove(i);
				
				((RadioGroup)v.getParent()).clearCheck();
				return true;
			}
		}
		
		return false;
	}
	
	public void onClickFamiliaRadioButton(View v)
	{
		for(Pair<View, Pair<String, String>> p : viewsFamilia)
		{
			if(p.first == v)
			{
				if(isRadioButtonCheckedFamilia(v, p.second))
					continue;
				
				addFiltroFamiliaRadioButton(p.second);
			}
		}
	}
	
	public void addFiltroFamiliaCheckBox(Pair<String, String> filtro)
	{
		for(int i = 0; i < filtroFamilia.size(); i++) // se existe remove e retorna
		{
			if(filtroFamilia.get(i).first == filtro.first && filtroFamilia.get(i).second == filtro.second)
			{
				filtroFamilia.remove(i);
				return;
			}
		}
		
		filtroFamilia.add(filtro); // se chegou aqui � porque n�o existe e basta adicionar
	}
	
	public void onClickFamiliaCheckBox(View v)
	{
		for(Pair<View, Pair<String, String>> p : viewsFamilia)
		{
			if(p.first == v)
			{
				addFiltroFamiliaCheckBox(p.second);
			}
		}
	}
	
	// Habitats
	
	List<Pair<View, String>> viewsHabitat = new ArrayList<Pair<View,String>>();
	String habitat = "";
	
	public void criarIdentificarHabitat()
	{
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		List<String> habitats = dba.getHabitats();
		
		dba.close();
		
		ViewGroup layout = (ViewGroup) findViewById(R.id.identificar_habitat);
		
		LinearLayout wraper = new LinearLayout(this);
		wraper.setOrientation(LinearLayout.VERTICAL);
		
		float density = this.getResources().getDisplayMetrics().density;
		
		wraper.setBackgroundResource(R.drawable.btn_default);
		wraper.setPadding((int) (15*density), (int) (10*density), (int) (15*density), (int) (10*density));
		
		TextView tv = new TextView(this);
		LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		tv.setLayoutParams(ll);
		tv.setTextAppearance(this, android.R.style.TextAppearance_Large);
		tv.setText("Habitats");
		
		wraper.addView(tv);
				
		RadioGroup rg = new RadioGroup(this);
		
		for(final String habitat : habitats)
		{
			RadioButton rb = new RadioButton(this);
			RadioGroup.LayoutParams lp = new RadioGroup.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
			lp.setMargins(0, 0, 0, 10);
			rb.setLayoutParams(lp);
			rb.setTextAppearance(this, android.R.style.TextAppearance_Medium);
			rb.setText(habitat);
			rb.setOnClickListener(new OnClickListener()
			{	
				@Override
				public void onClick(View v)
				{
					onClickHabitat(v);
				}
			});
			
			viewsHabitat.add(new Pair<View, String>(rb, habitat));
			
			rg.addView(rb);
		}
		
		wraper.addView(rg);
		
		layout.addView(wraper);
	}
	
	public void onClickHabitat(View v)
	{
    	for(Pair<View, String> p : viewsHabitat)
    	{
    		if(v == p.first)
    		{
    			if(habitat.equals(p.second))
    			{
    				habitat = "";
    				((RadioGroup)v.getParent()).clearCheck();
    				continue;
    			}
    			
    			habitat = p.second;
    			Log.i("debug", p.second);
    		}
    	}
	}
	
	//

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.identificar_activity);
		
		criarIdentificarSubOrdem();
		criarIdentificarFamilia();
		criarIdentificarHabitat();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.identificar, menu);
		return true;
	}
    
	private String getMes(int mes)
	{
        String[] meses = new String[]{"JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"};
        
        return meses[mes];
	}
	
	private boolean dataAtual = false;
	
	public void onClickDataAtual(View v)
	{
		if(v.getId() == R.id.identificar_data_cb)
		{
			if(dataAtual)
				dataAtual = false;
			else
				dataAtual = true;
		}
	}
	
    @SuppressLint("SimpleDateFormat")
	public void identificar(View view)
    {
    	List<Pair<String, String>> filtro = new ArrayList<Pair<String,String>>();
    	
    	filtro.addAll(filtroSubOrdem);
    	filtro.addAll(filtroFamilia);
    	
    	String mes = "";
    	
    	if(dataAtual)
    	{
			Calendar c = Calendar.getInstance();
			mes = getMes(c.get(Calendar.MONTH));
    	}
		
		Identificacao identificacao = new Identificacao(this);
		
		List<String> especies = identificacao.filterEspecies(filtro, habitat, mes);
    	
    	Intent intent = new Intent(this, IdentificarResultadosActivity.class);
    	intent.putStringArrayListExtra("especies", (ArrayList<String>) especies);
    	startActivity(intent);
    }
}
