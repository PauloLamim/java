package ualg.les.libapp;

import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SubOrdemActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sub_ordem_activity);
		
		Intent intent = getIntent();
		String subOrdem = intent.getExtras().getString("subOrdem");
		
		ViewGroup layout = (ViewGroup) findViewById(R.id.subOrdem);
		
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		Log.i("debug", subOrdem);
		
		float density = this.getResources().getDisplayMetrics().density;
		
		List<String> familias = dba.getFamilias(subOrdem);
		
		for(String familia : familias)
		{
			Log.i("debug", "    "+familia);
			
			// FamiliaHasChilds()
			
			if(!dba.getEspecies(familia).isEmpty())
			{
				TextView tv1 = new TextView(this);
				LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
				tv1.setLayoutParams(ll);
				tv1.setTextAppearance(this, android.R.style.TextAppearance_Large);
				tv1.setTextSize(30*density);
				tv1.setText(""+familia);
				layout.addView(tv1);
				
				List<String> especies = dba.getEspecies(familia);
				
				for(final String especie : especies)
				{
					Log.i("debug", "        "+especie);
					
					TextView tv11 = new TextView(this);
					LinearLayout.LayoutParams ll2 = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
					ll2.setMargins(0, (int) (8*density), 0, (int) (8*density));
					tv11.setLayoutParams(ll2);
					tv11.setTextAppearance(this, android.R.style.TextAppearance_Large);
					tv11.setText("- " + especie);
					tv11.setTypeface(null, Typeface.ITALIC);
					try
					{
						tv11.setTextColor(ColorStateList.createFromXml(getResources(), getResources().getXml(R.color.link_color)));
					}
					catch (Exception e)
					{
						
					}
					tv11.setOnClickListener(new OnClickListener()
					{	
						@Override
						public void onClick(View v)
						{
					    	goToFicha(especie);
						}
					});
					layout.addView(tv11);
				}
			}
		}
		
		dba.close();
	}

	private void goToFicha(String especie)
	{
		Intent intent = new Intent(this, FichaActivity.class);
    	intent.putExtra("especie", especie);
    	startActivity(intent);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.sub_ordem, menu);
		return true;
	}

}
