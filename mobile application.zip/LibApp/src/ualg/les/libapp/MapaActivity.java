package ualg.les.libapp;

import java.util.List;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Pair;
import android.view.Menu;

public class MapaActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mapa_activity);
		
		Intent intent = getIntent();
		String especie = intent.getExtras().getString("especie");
		
		
		DBAdapter dba = new DBAdapter(this);
		dba.open();
		
		List<Pair<Double, Double>> coordenadas = dba.getCoordenadas(especie);
		
		dba.close();
		
		
		GoogleMap map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
		
		for(Pair<Double, Double> coordenada : coordenadas)
		{
			MarkerOptions marker = new MarkerOptions()
			.position(new LatLng(coordenada.first, coordenada.second));
			//.title(especie);
			//.snippet("");
			
			map.addMarker(marker);
		}
		
		map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
		LatLng ALGARVE = new LatLng(37.25656608611523, -8.191680908203125);
		CameraUpdate update = CameraUpdateFactory.newLatLngZoom(ALGARVE, 8);
		map.animateCamera(update);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.mapa, menu);
		return true;
	}

}
