package it.sephiroth.android.library.imagezoom;

public interface IDisposable {
	void dispose();
}
