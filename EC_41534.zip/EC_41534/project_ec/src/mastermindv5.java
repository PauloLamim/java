import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;

public class mastermindv5 {
	public static int guesses = 0;
	public static int[] generateSecretCode(int n, int c)
	{
		Random r = new Random();
		int[] g = new int[n];
		for(int i=0;i<n;i++)
		{
			g[i] = r.nextInt((c+1) - 1) + 1;
		}
		return g;
	}
	
	public static int[] generateRandomSequence(int n, int c)
	{
		Random r = new Random();
		int[] g = new int[n+3];
		for(int i=0;i<n;i++)
		{
			g[i] = r.nextInt((c+1) - 1) + 1;
		}
		g[n] = 0; //set white pins for this sequence to 0
		g[n+1] = 0; //set black pins for this sequence to 0
		g[n+2] = 0; //set position to 0 before calculating fitness
		return g;
	}
	
	public static void printA(int[] a, int n)
	{
		for(int i=0;i<n;i++)
		{
			System.out.print(a[i] + " ");
		}
	}
	
	public static int[] getPins(int[] s, int[] g, int n)
	{
		int[] result = {0,0}; //primeira posicao contagem de whites, segunda contagem de blacks
		int[] s1 = new int[n];
		int[] g1 = new int[n];
		System.arraycopy(s, 0, s1, 0, n);
		System.arraycopy(g, 0, g1, 0, n);
		
		for(int i=0;i<n;i++)
		{
			if(s1[i]==g1[i])
			{
				result[0]++;
				s1[i] = 0;
				g1[i] = 0;
			}
		}
		
		outer:
		for(int i=0;i<n;i++)
		{
			if(g1[i]!=0)
			{
				for(int j=0;j<n;j++)
				{
					if(g1[i]==s1[j])
					{
						result[1]++;
						s1[j]=0;
						continue outer;
					}
				}
			}
		}
		return result;
	}
	
	public static int calculateFitness(int x, int y)
	{
		//int fit = Math.abs(x-y);
		int fit = (int) (x + (y*0.5)); //brancos tem um peso 1 e pretos tem peso 0.5
		//System.out.println(fit);
		return fit;
	}
	
	public static ArrayList<int[]> createPopulation(int p, int c,int size, int pop_size, int[] secret)
	{
		ArrayList<int[]> newpopulation = new ArrayList<int[]>();
		//init population with random guesses
		int i=0;
		while(i<pop_size)
		{
			int[] temp = generateRandomSequence(p,c);
			int[] t_pins = getPins(secret,temp,p);
			temp[p] = t_pins[0];
			temp[p+1] = t_pins[1];
			temp[p+2] = calculateFitness(temp[p],temp[p+1]);
			if(newpopulation.contains(temp)==false)
			{
				newpopulation.add(temp);
				i++;
			}
		}
		
		return newpopulation;
	}
	
	public static void printPopulation(ArrayList<int[]> pop, int p, int size, int pop_size)
	{
		System.out.println("");
		for(int z=0;z<size;z++)
		{
			if(z<size-3)
				System.out.print(z+1 + "|");
			if(z==(size-3))
				System.out.print("W|"); //white pins
			if(z==(size-2))
				System.out.print("B|"); //black pins
			if(z==(size-1))
				System.out.println("F"); //fitness
		}
		System.out.println("-------------------------");
		for(int i=0;i<pop_size;i++)
		{
			for(int j=0;j<size;j++)
			{
				System.out.print(pop.get(i)[j] + " ");
			}
			System.out.println("");;
		}
	}
	
	public static ArrayList<int[]> crossover (ArrayList<int[]> pop,int p, int size, int pop_size,int[] secret)
	{
		ArrayList<int[]> newpop = new ArrayList<int[]>();
		Random rnd = new Random();
		//create children based on the best 1st half of the initial population
		//for(int i=0;i<pop_size;i++)
		int i=0;
		while(i<pop_size)
		{
			//get 1st parent position
			int p1 = rnd.nextInt((pop_size/2)-0);
			//get 2nd parent position
			int p2 = rnd.nextInt((pop_size/2)-0);
			//get cutpoint
			int cutpoint = rnd.nextInt(p-1) + 1;
			
			int[] newchild = new int[size];
			
			//create child
			for(int j=0;j<cutpoint;j++)
			{
				newchild[j] = pop.get(p1)[j];
			}
			for(int j=cutpoint;j<p;j++)
			{
				newchild[j] = pop.get(p2)[j];
			}
			int[] t_pins = getPins(secret,newchild,p);
			newchild[p] = t_pins[0];
			newchild[p+1] = t_pins[1];
			newchild[p+2] = calculateFitness(newchild[p],newchild[p+1]);
			if(!newpop.contains(newchild))
			{	
				newpop.add(newchild);
				i++;
			}
			//System.out.println("Cutpoint: " + cutpoint);
			//System.out.println("1st parent: " + Arrays.toString(pop.get(p1)));
			//System.out.println("2nd parent: " + Arrays.toString(pop.get(p2)));
			//System.out.println("Child: " + Arrays.toString(newchild));
		}
		return newpop;
	}
	
	public static void mutation(ArrayList<int[]> pop, int p, int c, final int size, int pop_size,int[] secret)
	{
		//Set a random prob. of mutation
		Random prb = new Random();
		double pm = prb.nextDouble();
		for(int i=0;i<pop_size;i++)
		{
			for(int j=0;j<p;j++)
			{
				double m = prb.nextDouble();
				if(m<pm)
				{
					int temp = prb.nextInt((c+1) -1 ) + 1;
					while(temp==pop.get(i)[j])
					{
						temp = prb.nextInt((c+1) -1 ) + 1;
					}
					pop.get(i)[j] = temp;
				}
			}
			int[] t_pins = getPins(secret,pop.get(i),p);
			pop.get(i)[p] = t_pins[0];
			pop.get(i)[p+1] = t_pins[1];
			pop.get(i)[p+2] = calculateFitness(pop.get(i)[p],pop.get(i)[p+1]);
		}
	}
	
	public static void inversion(ArrayList<int[]> pop, int p, int c, final int size, int pop_size,int[] secret)
	{
		Random r = new Random();
		double pinv = r.nextDouble(); //probability of inversion
		for(int i=0;i<pop_size;i++)
		{
			double rnd = r.nextDouble();
			if(rnd<pinv)
			{
				int pos1 = r.nextInt(p);
				int pos2 = r.nextInt(p);
				
				if(pos2<pos1)
				{
					int temp = pos2;
					pos2 = pos1;
					pos1 = temp;
				}
				
				//store sub-sequence
				int[] store = new int[pos2-pos1];
				int[] rev = new int[pos2-pos1];
				int result=0;
				for(int j=pos1;j<pos2;j++)
				{
					store[result] = pop.get(i)[j];
					result++;
				}
				int s = 0;
				//reverse sub-sequence
				for(int m=(pos2-pos1-1);m>=0;m--)
				{
					rev[s] = store[m];
					s++;
				}
				s=0; //reset s
				//Substitute in sequence
				for(int j=pos1;j<pos2;j++)
				{
					pop.get(i)[j] = rev[s];
					s++;
				}
				int[] t_pins = getPins(secret,pop.get(i),p);
				pop.get(i)[p] = t_pins[0];
				pop.get(i)[p+1] = t_pins[1];
				pop.get(i)[p+2] = calculateFitness(pop.get(i)[p],pop.get(i)[p+1]);
			}
		}
	}
	
	public static void sortList(ArrayList<int[]> pop, final int size)
	{
		Collections.sort(pop, new Comparator<int[]>() {
            private final int INDEX = (size-1);
            @Override
            public int compare(int[] o1, int[] o2) {
                return Integer.compare(o1[INDEX], o2[INDEX]);
            }
        });
	}
	
	public static ArrayList<int[]> reverseOrder(ArrayList<int[]> pop,int pop_size)
	{
		ArrayList<int[]> poporder = new ArrayList<int[]>();
		
		for(int i=(pop_size-1);i>=0;i--)
		{
			poporder.add(pop.get(i));
		}
		return poporder;
	}
	
	public static boolean comparePreviousGuesses(ArrayList<int[]> pg,int[] g,int size)
	{
		for(int i=0;i<pg.size();i++)
		{
			if(g[size-1]<pg.get(i)[size-1])
				return false;
		}
		return true;
	}
	
	public static int[] inversionGuess(int[] g, int p, final int size)
	{
		int[] invguess = new int[size];
		
		Random r = new Random();
		int pos1 = r.nextInt(p);
		int pos2 = r.nextInt(p);
		int result = 0;
		
		if(pos2<pos1)
		{
			int temp = pos2;
			pos2 = pos1;
			pos1 = temp;
		}
		
		for(int i=0;i<pos1;i++)
		{
			invguess[result] = g[i];
			result++;
		}
		for(int i=(pos2-1);i>=pos1;i--)
		{
			invguess[result] = g[i];
			result++;
		}
		for(int i=pos2;i<p;i++)
		{
			invguess[result] = g[i];
			result++;
		}
		return invguess;
	}
	
	/*public static boolean isInList(ArrayList<int[]> a, int[]t)
	{
		for(int[] e: a)
		{
			if(Arrays.equals(e, t))
			{
				return true;
			}
		}
		return false;
	}*/
	
	public static boolean isInList(ArrayList<int[]> a, int[]t)
	{
		int result = 0;
		int max = 4;
		for(int[] e: a)
		{
			result=0;
			for(int i=0;i<4;i++)
			{
				if(e[i]==t[i])
					result++;
			}
			if(result==max)
				return true;
		}
		return false;
	}
	
	public static int playMastermind(int p, int c, int[] secret, int population_size, int max_gen,int gamewon, int gamelost, int max_number_guesses)
	{
		int game = 0;
		int x = 0; //number of whites
		int y = 0; //number of blacks
		//set i = 1
		int i = 1;
		//Play initial guess for 1st turn
		int[] guess = generateRandomSequence(p,c);
		final int size = p + 3; //size = number pos + the pos of white pins + the pos of black pins + fitness
		System.out.println("Initial Guess");
		//printA(guess,size);
		printA(guess,p);
		System.out.println("");
		//Get response for black and white pins
		int[] pins = getPins(secret,guess,p);
		System.out.println("Number of white pins: " + pins[0]);
		System.out.println("Number of black pins: " + pins[1]);
		//Set x and y
		x = pins[0];
		y = pins[1];
		guess[p] = pins[0];
		guess[p+1] = pins[1];
		guess[p+2] = calculateFitness(guess[p],guess[p+1]);
		//List of played guesses
		ArrayList<int[]> played_guess = new ArrayList<int[]>();
		played_guess.add(guess);
		
		//Best guess of the game
		int[] best = new int[p];
		//int current_played_size = played_guess.size();
		
		//check x, y and last 2 positions of guess
		//System.out.println("x: " + x);
		//System.out.println("y: " + y);
		//printA(guess,size);
		System.out.println("End of turn: " + i);
		//while white pins different from colors of secret code or until then of the 10 turns
		//while(x!=p && i<10)
		//while(x!=p)
		while(x!=p && i<max_number_guesses)
		{
			//Play next turn
			i+= 1;
			//Initialize List of candidate codes and initial generation
			ArrayList<int[]> e = new ArrayList<int[]>();
			int gen = 1;
			
			//System.out.println("Current gen: " + gen);
			//System.out.println("Current turn: " + i);
			
			//Initialize the population
			ArrayList<int[]> population = createPopulation(p, c,size, population_size, played_guess.get(played_guess.size()-1));
			//sort population by fitness
			sortList(population,size);
			//printPopulation(population,p,size,population_size);
			//System.out.println("Order Descending");
			population = reverseOrder(population,population_size);
			//printPopulation(population,p,size,population_size);
			//while <=max generation and <= max size do
			while(gen<=max_gen)
			{
				//Generate new population using crossover, mutation, inversion and permutation
				//System.out.println("After crossover and before mutation");
				ArrayList<int[]> newgeneration = crossover(population,p,size,population_size,played_guess.get(played_guess.size()-1));
				//printPopulation(newgeneration,p,size,population_size);
				sortList(newgeneration,size);
				newgeneration = reverseOrder(newgeneration,population_size);
				//printPopulation(newgeneration,p,size,population_size);
				//System.out.println("After mutation");
				mutation(newgeneration,p,c,size,population_size,played_guess.get(played_guess.size()-1));
				sortList(newgeneration,size);
				newgeneration = reverseOrder(newgeneration,population_size);
				//printPopulation(newgeneration,p,size,population_size);
				//System.out.println("After inversion");
				inversion(newgeneration,p,c,size,population_size,played_guess.get(played_guess.size()-1));
				sortList(newgeneration,size);
				newgeneration = reverseOrder(newgeneration,population_size);
				//printPopulation(newgeneration,p,size,population_size);
				
				//sort played guess by fit
				//sortList(played_guess,size);
				
				//Add the best combination of a generation to the list of candidates, if it is not contained in the list
				int t=0;
				//while(t<newgeneration.size() && e.contains(newgeneration.get(t)))
				while(t<newgeneration.size() && isInList(e,newgeneration.get(t)))
				{
					t++;
				}
				if(t<newgeneration.size())
				{
					if(isInList(played_guess,newgeneration.get(t))==false)
					{
						if(comparePreviousGuesses(played_guess,newgeneration.get(t),size)==true)
						{	
							e.add(newgeneration.get(t));
						}	
						else
						{
							int[] gtemp = played_guess.get(0);
							int[] invGuess = inversionGuess(gtemp,p,size);
							int z =0;
							//while(e.contains(invGuess) && z<100)
							//while(played_guess.contains(invGuess)==true)
							while(isInList(played_guess,invGuess)==true && z< 100)
							{
								invGuess = inversionGuess(gtemp,p,size);
								z++;
							}
							//if(played_guess.contains(invGuess)==false)
							if(isInList(played_guess,invGuess)==false)
								e.add(invGuess);
						}
					}
				}
				
				//add one to max gen
				gen+=gen;
			//end while
			}
			//order candidates by fitness
			sortList(e,size);
			e = reverseOrder(e,e.size());
			//play one guess from the list
			int[] nextguess = new int[size];
			int w = 0;
			if(e.size()!=0)
			{
				nextguess = e.get(w);
				while(isInList(played_guess,nextguess)==true && w<e.size())
				{
					w++;
					nextguess = e.get(w);
				}
			}
			else
			{
				nextguess = generateRandomSequence(p,c);
				pins = getPins(secret,nextguess,p);
				nextguess[p] = pins[0];
				nextguess[p+1] = pins[1];
				nextguess[p+2] = calculateFitness(nextguess[p],nextguess[p+1]);
			}
			System.out.println("---------------------------------------");
			if(isInList(played_guess,nextguess)==true)
			{
				int u=0;
				//System.out.println("J� foi usada essa guess: " + Arrays.toString(nextguess));
				while(isInList(played_guess,nextguess)==true && u<100)
				{
					nextguess = generateRandomSequence(p,c);
					pins = getPins(secret,nextguess,p);
					nextguess[p] = pins[0];
					nextguess[p+1] = pins[1];
					nextguess[p+2] = calculateFitness(nextguess[p],nextguess[p+1]);
					u++;
				}
				System.out.println("Secret code:");
				printA(secret,p);
				System.out.println("");
				System.out.println("Guess: ");
				printA(nextguess,p);
				System.out.println("");
				//Get a response for white and black pins
				pins = getPins(secret,nextguess,p);
				System.out.println("Number of white pins: " + pins[0]);
				System.out.println("Number of black pins: " + pins[1]);
				System.out.println("End of turn: " + i);
				
				nextguess[p] = pins[0];
				nextguess[p+1] = pins[1];
				nextguess[p+2] = calculateFitness(nextguess[p],nextguess[p+1]);
				x = pins[0];
				//add guess to the played guess list
				played_guess.add(nextguess);
			}
			else
			{
				System.out.println("Secret code:");
				printA(secret,p);
				System.out.println("");
				System.out.println("Guess: ");
				printA(nextguess,p);
				System.out.println("");
				//Get a response for white and black pins
				pins = getPins(secret,nextguess,p);
				System.out.println("Number of white pins: " + pins[0]);
				System.out.println("Number of black pins: " + pins[1]);
				System.out.println("End of turn: " + i);
				
				nextguess[p] = pins[0];
				nextguess[p+1] = pins[1];
				nextguess[p+2] = calculateFitness(nextguess[p],nextguess[p+1]);
				x = pins[0];
				//add guess to the played guess list
				played_guess.add(nextguess);
			}
			guesses++;
		}
		
		if(x==p && i<max_number_guesses)
		{
			game=1;
		}
		else
		{
			game=0;
		}
		return game;
		//Jogadas do jogo
		//System.out.println("Jogadas do Jogo:");
		//printPopulation(played_guess,p,size,played_guess.size());
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int population_size = 500;
		int max_gen = 500;
		int max_number_guesses = 10000;
		//int max_feasible_code = 1;
		
		//Initalize variables
		//Set number of positions, check text file for the setup
		System.out.println("Set number of positions:");
		int pos = sc.nextInt();
		//Set number of colors
		System.out.println("Set number of colors:");
		int colors = sc.nextInt();
		
		//Set number of repetitions
		System.out.println("Set number of repetitions of the same game:");
		int repetitions = sc.nextInt();
		
		//Set Secret Code
		int [] secret_code = generateSecretCode(pos,colors);
		
		//Check if everything was setting ok
		//System.out.println("Number of positions: " + pos);
		//System.out.println("Number of colors: " + colors);
		System.out.println("Secret code:");
		printA(secret_code,pos);
		System.out.println("");
		
		//teste random sequence
		//int[] random_sequence = generateRandomSequence(pos,colors);
		//int size = pos + 2;
		//printA(random_sequence,size);
		
		//playMastermind(pos,colors,secret_code,population_size,max_gen,max_feasible_code);
		long start = System.currentTimeMillis();
		long durationLongest = 0;
		long durationShortest = 4000000;
		int checkgame = 0;
		int gamewon = 0;
		int gamelost = 0;
		//Play the same game 10 times
		for(int i=0;i<repetitions;i++)
		{
			long start_time = System.currentTimeMillis();
			checkgame = playMastermind(pos,colors,secret_code,population_size,max_gen,gamewon,gamelost,max_number_guesses);
			long end_time = System.currentTimeMillis();
			
			if(checkgame==1)
				gamewon++;
			else
				gamelost++;
			
			if((end_time - start_time) > durationLongest)
			{
				durationLongest = end_time -start_time;
			}
			if((end_time - start_time) < durationShortest)
			{
				durationShortest = end_time -start_time;
			}
		}
		long end = System.currentTimeMillis();
		long duration = end - start;
		System.out.println("-----------------------------------");
		System.out.println("Results: ");
		System.out.println("Repetitions: " + repetitions);
		System.out.println("Duration in ms: " + duration);
		System.out.println("Duration in s: " + (duration/1000f));
		System.out.println("Duration in m: " + (duration/1000f/60));
		System.out.println("Average Solving Time in ms: " +(duration/repetitions));
		System.out.println("Average Solving Time in s: " +(duration/1000f/repetitions));
		System.out.println("Shortest in ms: " + durationShortest);
		System.out.println("Longest in ms: " + durationLongest);
		System.out.println("Shortest in s: " + durationShortest/1000f);
		System.out.println("Longest in s: " + durationLongest/1000f);
		System.out.println("Longest in m: " + durationLongest/1000f/60);
		System.out.println("Won: " + gamewon);
		System.out.println("Lost: " + gamelost);
		System.out.println("Average Guesses: " + (guesses/repetitions));
	}

}