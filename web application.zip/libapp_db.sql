CREATE DATABASE  IF NOT EXISTS `db_libelinhas` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `db_libelinhas`;
-- MySQL dump 10.13  Distrib 5.6.10, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_libelinhas
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atributos_familia`
--

DROP TABLE IF EXISTS `atributos_familia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atributos_familia` (
  `idatributos_familia` int(11) NOT NULL AUTO_INCREMENT,
  `nome` text,
  `descricao` text,
  PRIMARY KEY (`idatributos_familia`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atributos_familia`
--

LOCK TABLES `atributos_familia` WRITE;
/*!40000 ALTER TABLE `atributos_familia` DISABLE KEYS */;
INSERT INTO `atributos_familia` VALUES (1,'Reflexos metálicos','Sim'),(2,'Reflexos metálicos','Não'),(3,'Cor','Cobre'),(4,'Cor','Púrpura'),(5,'Cor','Verde'),(6,'Cor','Azul'),(7,'Cor','Bronze'),(8,'Cor','Negra'),(9,'Cor','Branca'),(10,'Cor','Alaranjada'),(11,'Cor','Amarela'),(12,'Cor','Castanho claro'),(13,'Cor','Escura'),(14,'Cor','Cinzento'),(15,'Formato das asas','Assimétricas'),(16,'Formato das asas','Simétricas'),(17,'Nervuras','Número elevado'),(18,'Nervuras','Número reduzido'),(19,'Asas','Opacas'),(20,'Asas','Transparentes'),(21,'Voo agitado e irregular','Sim'),(22,'Patas','Compridas'),(23,'Patas','Curtas'),(24,'Voo agitado e irregular','Não');
/*!40000 ALTER TABLE `atributos_familia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `atributos_sub_ordem`
--

DROP TABLE IF EXISTS `atributos_sub_ordem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atributos_sub_ordem` (
  `idatributos_sub_ordem` int(11) NOT NULL AUTO_INCREMENT,
  `nome` text,
  `descricao` text,
  PRIMARY KEY (`idatributos_sub_ordem`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atributos_sub_ordem`
--

LOCK TABLES `atributos_sub_ordem` WRITE;
/*!40000 ALTER TABLE `atributos_sub_ordem` DISABLE KEYS */;
INSERT INTO `atributos_sub_ordem` VALUES (1,'Aparência','Frágil'),(2,'Aparência','Robusta'),(3,'Asas anteriores e posteriores','Semelhantes'),(4,'Asas anteriores e posteriores','Diferentes'),(5,'Asas quando pousado','Junto ao corpo'),(6,'Asas quando pousado','Afastadas do corpo'),(7,'Cabeça','Mais larga que o corpo'),(8,'Cabeça','Mais estreita que o corpo'),(9,'Olhos','Individualizados'),(10,'Olhos','Unidos'),(11,'Ovipositor','Sim'),(12,'Ovipositor','Não');
/*!40000 ALTER TABLE `atributos_sub_ordem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes_dimensao`
--

DROP TABLE IF EXISTS `classes_dimensao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes_dimensao` (
  `nome` varchar(45) NOT NULL,
  `descricao` text,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes_dimensao`
--

LOCK TABLES `classes_dimensao` WRITE;
/*!40000 ALTER TABLE `classes_dimensao` DISABLE KEYS */;
INSERT INTO `classes_dimensao` VALUES ('a','1 a 10 indivíduos'),('b','11 a 50 indivíduos'),('c','mais de 50 indivíduos'),('d','imensos, incontável'),('x','informação não disponível');
/*!40000 ALTER TABLE `classes_dimensao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contributos`
--

DROP TABLE IF EXISTS `contributos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contributos` (
  `idcontributos` int(11) NOT NULL AUTO_INCREMENT,
  `longitude` text,
  `latitude` text,
  `nome_local` text,
  `data` text,
  `observacoes` text,
  `estado_contributo_nome` varchar(45) NOT NULL,
  `estadio_ciclo_vida_nome` varchar(45) NOT NULL,
  `utilizadores_nome_utilizador` varchar(45) NOT NULL,
  `especie_nome` varchar(45) NOT NULL,
  `classes_dimensao_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idcontributos`),
  KEY `fk_contributos_estado_contributo1_idx` (`estado_contributo_nome`),
  KEY `fk_contributos_estadio_ciclo_vida1_idx` (`estadio_ciclo_vida_nome`),
  KEY `fk_contributos_utilizadores1_idx` (`utilizadores_nome_utilizador`),
  KEY `fk_contributos_especie1_idx` (`especie_nome`),
  KEY `fk_contributos_classes_dimensao1_idx` (`classes_dimensao_nome`),
  CONSTRAINT `fk_contributos_classes_dimensao1` FOREIGN KEY (`classes_dimensao_nome`) REFERENCES `classes_dimensao` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_contributos_especie1` FOREIGN KEY (`especie_nome`) REFERENCES `especie` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_contributos_estadio_ciclo_vida1` FOREIGN KEY (`estadio_ciclo_vida_nome`) REFERENCES `estadio_ciclo_vida` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_contributos_estado_contributo1` FOREIGN KEY (`estado_contributo_nome`) REFERENCES `estado_contributo` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_contributos_utilizadores1` FOREIGN KEY (`utilizadores_nome_utilizador`) REFERENCES `utilizadores` (`nome_utilizador`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contributos`
--

LOCK TABLES `contributos` WRITE;
/*!40000 ALTER TABLE `contributos` DISABLE KEYS */;
INSERT INTO `contributos` VALUES (4,'-7.97126036','37.04510974',NULL,'27/Jun/2013','','aceite','A','admin','Calopteryx haemorrhoidalis','a'),(5,'-7.97126488','37.04512338',NULL,'27/Jun/2013','','aceite','Ao','admin','Calopteryx haemorrhoidalis','d'),(6,'-7.97126629','37.04512393',NULL,'27/Jun/2013','','aceite','Ao','admin','Ceriagrion tenellum','d'),(7,'-7.97135104','37.04511841',NULL,'27/Jun/2013','','aceite','E','admin','Ceriagrion tenellum','b'),(8,'-7.97152343','37.04443579',NULL,'27/Jun/2013','Hey ','aceite','Ao','admin','Calopteryx haemorrhoidalis','d'),(9,'-7.97142898','37.04504286',NULL,'27/Jun/2013','Ok ','aceite','A','admin','Aeshna cyanea','a'),(10,'-7.97136722','37.04507207',NULL,'27/Jun/2013','asd ','aceite','A','admin','Aeshna isoceles','a'),(11,'-7.97138199','37.04507024','dsad','27/Jun/2013','Gonç ','aceite','A','admin','Brachythemis impartita','a'),(12,'-7.97138415','37.04506917',NULL,'27/Jun/2013','watt ','aceite','A','admin','Aeshna cyanea','a'),(13,'-7.97138548','37.0450674',NULL,'27/Jun/2013','Contributo. ','aceite','Ac','FCorvelo','Platycnemis acutipennis','d');
/*!40000 ALTER TABLE `contributos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especie`
--

DROP TABLE IF EXISTS `especie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especie` (
  `nome` varchar(45) NOT NULL,
  `nome_ingles` text,
  `tendencia` text,
  `descobridor` text,
  `ano_descoberta` int(11) DEFAULT NULL,
  `estatuto_conservacao` text,
  `epoca_voo` text,
  `identificacao` text,
  `outras_informacoes` text,
  `fontes_informacao` text,
  `familia_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`nome`),
  KEY `fk_especie_familia1_idx` (`familia_nome`),
  CONSTRAINT `fk_especie_familia1` FOREIGN KEY (`familia_nome`) REFERENCES `familia` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especie`
--

LOCK TABLES `especie` WRITE;
/*!40000 ALTER TABLE `especie` DISABLE KEYS */;
INSERT INTO `especie` VALUES ('Aeshna cyanea','Blue Hawker','Estável','Müller',1764,'LC (Least Concern)','_NOV:','adulto, castanhos na FÊMEA. No TÓRAX de ambos, que é castanho escuro, faixas anteumerais verdes e\r\nlargas (elemento de diagnóstico); em visão lateral, duas faixas oblíquas, também verdes e muito estendidas.\r\nNo MACHO adulto, aurículas azuis; no ABDÓMEN, em visão dorsal, nos quartos posteriores de S2 a\r\nS7 destacam-se duas manchas verdes por segmento; em S8 as duas manchas são azuis; em S9 e S10 o azul\r\né mais estendido (elemento de diagnóstico); em visão lateral, observam-se também manchas azuis, mas\r\nnos quartos anteriores de S2 a S8. Na FÊMEA, o padrão das manchas abdominais é semelhante, mas sempre\r\nde cor verde-amarelada (elemento de diagnóstico). Nas ASAS, de membranas incolores, PTEROSTIGMAS\r\nescuros e curtos; no macho, a membrânula termina antes do limite posterior do triângulo anal, o\r\nqual tem pelo menos três células.','Filogeneticamente parece ser bastante distinta das restantes Aeshna sp. Pode ser considerada uma raridade\r\nno Algarve. Ovip.AF. Espécie semivoltina (Corbet et al. 2006).','Malkmus & Ruf (2008)','Aeshnidae'),('Aeshna isoceles','Green-eyed Hawker','Estável','Müller',1767,'LC (Least Concern)','_MAI_JUN:','Os adultos têm cerca de 64 mm de comprimento total. Predomina o castanho avermelhado em todo o\r\ncorpo (elemento de diagnóstico); no ABDÓMEN não se observa o padrão de cores caraterístico do Género\r\nnem surgem partes em azul e/ou verde. No MACHO, e também na FÊMEA, os OLHOS são verdes (elemento\r\nde diagnóstico), a fronte e peças bucais amarelas; no TÓRAX existem, em visão lateral, duas faixas\r\noblíquas amarelas pouco percetíveis; no ABDÓMEN, em visão dorsal e a todo o comprimento de S2, destaca-\r\nse um triângulo amarelo (elemento de diagnóstico); os PTEROSTIGMAS são alaranjados. No MACHO,\r\nno triângulo anal da ASA POSTERIOR, contíguo à membrânula que é bastante alongada e cinzenta escura,\r\nsobressai um alinhamento de membranas alares cor-de-laranja (elemento de diagnóstico).','Por vezes designada como Aeshna isosceles. Pode ser considerada uma raridade no Algarve, onde deverá\r\nser a Aeshna sp. mais temporã. O único registo para o Algarve ocorreu no ano de 1995; no entanto, Boulot\r\net al. 2009 assinalam a sua ocorrência no litoral oeste da região. Ovip.AF.','Gardiner & Wallis (1996)','Aeshnidae'),('Brachythemis impartita','Northern Banded Groundling','Aumento','Karsch',1890,'LC (Least Concern)','_MAI_JUN:','Os adultos têm cerca de 32 mm de comprimento total. Espécie de identificação muito simples, por ser\r\nquase inconfundível. MACHO adulto tem uma banda castanha escura no meio de cada ASA, entre o nódulo\r\ne o PTEROSTIGMA (elemento de diagnóstico fundamental), que é praticamente branco; asas da FÊMEA\r\nadulta têm, ocasionalmente, bandas semelhantes, mas menos visíveis. No MACHO adulto, OLHOS castanhos\r\nescuros. TÓRAX castanho escuro ou quase negro, com abundante pelugem cinzenta. ABDÓMEN\r\nquase negro; apêndices abdominais relativamente curtos, muito claros, curvados para baixo e com as extremidades\r\na tocarem-se. FÊMEA adulta tem o corpo castanho claro, com três sequências longitudinais de\r\npequenas manchas escuras no abdómen. ASAS têm membranas transparentes, à exceção da banda escura\r\nreferida; nervação predominantemente escura, embora algumas nervuras na parte anterior possam ser\r\nmuito claras. PATAS negras, com finas linhas castanhas claras nas tíbias.','Espécie Afrotropical e que ocorre também na Europa, a sul da latitude 40º N. No Algarve pode ser considerada\r\numa raridade. Durante muito tempo foi confundida com B. leucosticta e só recentemente, com o\r\nestudo de Dijkstra & Matushkina, ficou estabelecida e clarificada a distinção entre as duas espécies. NA\r\ncritical checklist of the Odonata of Portugal apenas se refere essa espécie para o Género Brachythemis.\r\nNo entanto, atualmente é consensual tratar-se de B. impartita (KD Dijkstra, pers. comm.). Embora a espécie\r\nnão surja listada em qualquer das publicações referidas na Introdução deste Guia Digital, Boulot et al.\r\n2009 assinalam já a sua ocorrência na região, numa posição concordante com a agora cartografada.',' ','Libellulidae'),('Calopteryx haemorrhoidalis','Copper Demoiselle','Estável','Vander Linden',1825,'LC (Least Concern)','_ABR_AGO_SET_OUT:MAI_JUN_JUL','Os adultos têm cerca de 45 a 47 mm de comprimento total. O MACHO tem o TÓRAX acobreado, púrpura\r\nou quase negro, mas nunca verde (elemento de diagnóstico); o ABDÓMEN pode ser de cor semelhante ao\r\ntórax, ou verde com reflexos metálicos; a parte ventral dos segmentos posteriores do abdómen é cor de\r\nrosa ou carmim (elemento de diagnóstico), por vezes intensa, e também as tíbias podem ter reflexos da\r\nmesma cor. As ASAS do macho são quase completa e intensamente pigmentadas de castanho escuro, ou\r\nde azul ou púrpura muito escuros; a parte proximal, no entanto, é transparente e a transição é oblíqua. A\r\nFÊMEA tem o corpo mais claro, em verde ou castanho, geralmente com reflexos metálicos; as ASAS são\r\ncastanhas claras e translúcidas; a ASA POSTERIOR é mais pigmentada no quarto distal (elemento de diagnóstico\r\nfundamental), em particular numa estreita faixa que delimita as partes translúcida e pigmentada.\r\nAs PATAS são acastanhadas.','Ocorre apenas nos países da bacia mediterrânica ocidental (sul da Europa e norte de África), mas tem distribuição\r\nalargada no Algarve. As populações, quando ocorrem, são geralmente numerosas. Ferreira et\r\nal. (2006) afirmam ser possível a existência de subespécies, já que o padrão das asas e o tamanho do corpo\r\nsão muito variáveis. Espécie semivoltina (Corbet et al. 2006).','Ferreira & Grosso-Silva (2006)\r\nGardiner & Sturgess (1994)\r\nKnijf & Demolder (2010)\r\nLohr (2005)\r\nMcLachlan (1880)','Calopterygidae'),('Calopteryx virgo meridionalis','Beautiful Demoiselle','Estável','Linnaeus',1758,'LC (Least Concern)','_ABR_MAI_JUN_JUL:','Os adultos têm cerca de 48 mm de comprimento total e constituição robusta; é a maior das três Espécies\r\nde Calopteryx que ocorrem no Algarve. O MACHO adulto tem o TÓRAX e o ABDÓMEN verdes ou azuis com\r\nreflexos metálicos (elemento de diagnóstico); a parte ventral dos segmentos posteriores do abdómen é\r\navermelhada (elemento de diagnóstico), embora menos percetível do que nas C. haemorrhoidalis; as ASAS\r\nsão mais largas do que nas restantes Calopteryx, castanhas escuras mas podendo apresentar reflexos azuis\r\nmetálicos eventualmente intensos (elemento de diagnóstico); a extremidade proximal das asas é transparente\r\ne a transição entre as partes pigmentada e transparente é relativamente abrupta. A FÊMEA tem o\r\ncorpo em verde ou bronze mais claros, com reflexos metálicos; as ASAS são translúcidas e castanhas amareladas\r\ncom pigmentação uniforme (elemento de diagnóstico). As PATAS são negras, no macho e na fêmea.','Espécie de distribuição europeia. Em Portugal continental não surge no Alentejo, mas ocorre no Algarve,\r\nembora com distribuição limitada. Espécie univoltina ou semivoltina (Corbet et al. 2006).','Knijf & Demolder (2010)','Calopterygidae'),('Ceriagrion tenellum','Small Red Damsel','Estável','De Villers',1789,'LC (Least Concern)','_MAR_AGO_SET_OUT:ABR_MAI_JUN_JUL','Os adultos têm cerca de 32 mm de comprimento total. No MACHO, OLHOS em vermelho-acastanhado;\r\nsem manchas pós-oculares; no TÓRAX, faixas anteumerais não existem ou são muito finas e incompletas;\r\nABDÓMEN totalmente vermelho (elemento de diagnóstico); apêndices abdominais superiores muito pequenos.\r\nAs FÊMEAS têm quatro formas cromáticas: i. typica, a mais comum, com a parte dorsal do abdómen\r\npredominantemente de cor bronze escuro, mas com os segmentos S1 a S4 e S10 vermelhos; ii.\r\nerythrogastrum, muito semelhante ao macho; iii. intermedium, com a parte dorsal do abdómen predominantemente\r\nvermelha, mas S5 ou S6 até S8 são de cor bronze escuro; iv. melanogastrum, com a parte dorsal\r\ndo abdómen quase totalmente em cor bronze escuro. Nas ASAS, parte proximal da nervação principal\r\navermelhada, mas com as membranas transparentes; PTEROSTIGMAS não são mais compridos do que as\r\ncélulas contíguas e são também avermelhados (elemento de diagnóstico). As PATAS são amarelas acastanhadas\r\nou vermelhas acastanhadas (elemento de diagnóstico).','Esta espécie e a P. nymphula são as únicas libelinhas que ocorrem no Algarve em que predominam as cores\r\nvermelha e preta. Apenas foram encontradas as formas cromáticas femininas typica e erythrogastrum.\r\nDistribuição limitada.','Ferreira & Grosso-Silva (2006)\r\nGardiner & Sturgess (1994)\r\nKnijf & Demolder (2010)\r\nLohr (2005)','Coenagrionidae'),('Coenagrion puella','Azure Bluet','Estável','Linnaeus',1758,'LC (Least Concern)','_ABR_MAI_JUN_JUL:','Os adultos têm cerca de 34 mm de comprimento total. As partes não negras do TÓRAX e do ABDÓMEN,\r\nno MACHO, são azuis; as FÊMEAS podem ter duas formas, dependendo da cor não negra: azuis (forma\r\nhomocromática) ou verdes (f. heterocromática). Na cabeça, marcas pós-oculares ovais ou circulares. No\r\nTÓRAX, faixas anteumerais médias a largas e completas, uma linha negra incompleta na sutura interpleural\r\ne outra completa na sutura metapleural. No ABDÓMEN do macho predomina a cor azul; o padrão dos\r\ndesenhos a negro nas partes dorsais dos diversos segmentos é o elemento de diagnóstico fundamental:\r\nem S2 (elemento de diagnóstico), desenho em U completo; S3 a S5 com desenhos limitados ao terço posterior\r\nde cada segmento e linhas laterais negras muito finas (elemento de diagnóstico fundamental); S7 é\r\no segmento mais escuro; S8 praticamente todo azul, mas com duas pequenas marcas negras laterais\r\n(elemento de diagnóstico); apêndices abdominais superiores mais curtos do que os inferiores. FÊMEA\r\nsem espinho vulvar. PTEROSTIGMAS monocromáticos cinzentos muito escuros ou negros.','Pode ser considerada uma raridade no Algarve. Embora a espécie não surja listada em qualquer das publicações\r\ncom as caraterísticas referidas na Introdução deste Guia Digital, Boulot et al. 2009 assinalam já\r\na sua ocorrência na região, numa posição concordante com a agora cartografada.\r\nA observação nas proximidades de São Marcos da Serra, publicada por McLachlan (1880), é o primeiro\r\nregisto da ocorrência da espécie em Portugal continental (Ferreira et al. 2006).','Gardiner & Sturgess (1995)\r\nMcLachlan (1880)','Coenagrionidae'),('Coenagrion scitulum','Dainty Bluet','Estável','Rambur',1842,'LC (Least Concern)','_ABR_JUN_JUL:MAI','Os adultos têm cerca de 32 mm de comprimento total. As partes não negras do TÓRAX e do ABDÓMEN,\r\nquer no MACHO, quer na FÊMEA, são azuis. Na cabeça, os OLHOS do MACHO são azuis, da FÊMEA verdes;\r\nmarcas pós-oculares circulares azuis. No TÓRAX, faixas anteumerais médias a largas e completas, uma linha\r\nnegra incompleta na sutura interpleural e outra linha negra completa, mas de espessura variável, na\r\nsutura metapleural. No ABDÓMEN do MACHO predomina a cor azul; o padrão dos desenhos a negro nas\r\npartes dorsais dos diversos segmentos é o elemento de diagnóstico fundamental; em S2 (elemento de\r\ndiagnóstico), desenho relativamente simples a lembrar uma cabeça estilizada de gato com orelhas compridas,\r\ne que contacta com um anel negro que separa S2 de S3; em S3, desenho com uma oval ou lança\r\npedunculada, cujo eixo maior é paralelo ao eixo principal do abdómen; S6 e S7 são completamente negros;\r\nS8 azul, bem como a parte anterior de S9; apêndices abdominais superiores mais curtos do que S10\r\ne maiores que os inferiores. O ABDÓMEN da FÊMEA, em visão dorsal, é quase inteiramente negro, apenas\r\ncom azul nos limites dos segmentos; sem espinho vulvar. PTEROSTIGMAS trapezoidais, ligeiramente mais\r\nlongos no limite distal, castanhos claros.','Uma raridade no Algarve. Oviposição em tandem (ovip.TD). A C. scitulum pode, eventualmente, ser confundida\r\ncom Coenagrion caerulescens, espécie cuja ocorrência no Algarve não está confirmada (de forma\r\ninequívoca, embora seja referida por Vieira et al. 2010).','Lohr (2005)','Coenagrionidae'),('Cordulegaster boltonii','Common Goldenring','Estável','Donovan',1807,'LC (Least Concern)','_MAI_JUN_JUL:','amarela, com uma faixa horizontal a meio; OLHOS verdes; parte posterior e inferior da cabeça negra, com\r\numa fina linha contígua à parte inferior dos olhos. Peças bucais amarelas. No TÓRAX, cinzento escuro,\r\nfaixas anteumerais amarelas; em visão lateral, há mais duas faixas amarelas largas e, entre elas, uma fina e\r\nigualmente amarela (elemento de diagnóstico fundamental). No ABDÓMEN, em visão dorsal, S1 é cinzento\r\nescuro, entre S1 e S2 há um anel amarelo; entre S3 e S9 há duas faixas amarelas que se prolongam lateralmente\r\ncom uma curvatura anterior; S10 é cinzento escuro. Apêndices abdominais superiores, no MACHO,\r\nnegros, a apontar para o exterior, com comprimentos semelhantes ou ligeiramente inferiores a S10,\r\ne com um pequeno dente na face ventral. Na FÊMEA adulta o ovipositor é bastante longo, com comprimento\r\nsemelhante a S9+S10, negro, e muito percetível no limite posterior do abdómen (elemento de diagnóstico\r\nfundamental). Na ASA POSTERIOR do macho, triângulo anal com, em geral, cinco células (elemento\r\nde diagnóstico). PTEROSTIGMAS bastante compridos, prolongando-se por cinco ou seis células\r\ncontíguas, e muito estreitos (elemento de diagnóstico); membrânulas cinzentas claras.','Uma raridade no Algarve. São reconhecidas quatro subespécies distintas. Askew (2004) lista-as como\r\nboltonii, trinacriae, immaculifrons e algirica. Dijkstra & Lewington (2010) e Boulot et al. 2009 não mencionam\r\na ssp. trinacriae mas, em alternativa, referem a iberica. O número de registos confirmados na região é\r\nmuito diminuto; a ssp. que deverá ocorrer, de acordo com Boulot et al. 2009, é a iberica.','Knijf & Demolder (2010)\r\nLohr (2005)','Cordulegastridae'),('Crocothemis erythraea','Broad Scarlet','Aumento','Brullé',1832,'LC (Least Concern)','_ABR_MAI_JUN_JUL_AGO_SET_OUT_NOV:','Os adultos têm cerca de 40 mm de comprimento total. MACHO adulto é praticamente inconfundível, por\r\nser quase totalmente vermelho vivo (elemento de diagnóstico fundamental) e poder apenas apresentar\r\numa linha negra longitudinal nos segmentos posteriores do abdómen. FÊMEA adulta é castanha dourada,\r\ncom faixas anteumerais brancas (elemento de diagnóstico), faixa branca no alinhamento dorsal do tórax,\r\nentre as asas esquerdas e direitas, e linha negra longitudinal no abdómen, em visão dorsal. ABDÓMEN\r\nlargo, ligeiramente ovalado em visão dorsal (elemento de diagnóstico). Nas ASAS anterior e posterior,\r\nnervação anterior vermelha. Na ASA ANTERIOR, nove a onze nervuras antenodais perpendiculares, todas\r\ncom alinhamentos contínuos entre as nervuras antenodais principais exterior e interior, exceção para a\r\nperpendicular mais próxima do nódulo alar, que existe entre as nervuras antenodais principal e central\r\nmas não entre as central e interior; triângulo com duas células. Na ASA POSTERIOR, mancha proximal\r\nbastante percetível, alaranjada no macho e amarela na fêmea (elemento de diagnóstico). PTEROSTIGMAS\r\ncastanhos amarelados, semelhantes nas asas anteriores e posteriores, e com cerca de 3,5 mm (elemento\r\nde diagnóstico). PATAS predominantemente vermelhas (elemento de diagnóstico).','Espécie Paleártica e Afrotropical, de distribuição alargada no Algarve. Cópula ocorre em voo e é bastante\r\nrápida, demorando apenas 10 a 15 segundos; oviposição com a fêmea em solitário (ovip.AF). Espécie\r\nbivoltina (Corbet et al. 2006).','Ferreira & Grosso-Silva (2006)\r\nGardiner & Sturgess (1994)\r\nKnijf & Demolder (2010)\r\nLohr (2005)\r\nMalkmus & Ruf (2008)\r\nVieira et al. (2010)\r\nWeihrauch & Weihrauch (2003)','Libellulidae'),('Gomphus graslinii','Pronged Clubtail','Decréscimo','Rambur',1842,'NT (Near Threatened)','_MAI_JUN_JUL:','Os adultos têm cerca de 48 mm de comprimento total. OLHOS azuis; fronte amarela. No TÓRAX, em visão\r\nlateral, primeira e segunda (a partir da carena dorsal) faixas negras quase se tocam dorsalmente, junto à\r\ncarena; segunda faixa negra muito mais próxima da terceira do que da primeira, e bastante mais larga do\r\nque a faixa amarela entre a segunda e terceira faixas negras. Quarta faixa negra visível apenas até ao nível\r\ndo metastigma (elementos de diagnóstico fundamentais). No MACHO, no ABDÓMEN, aurículas em S2;\r\nquase não há dilatação em S8 e S9; todos os segmentos com manchas amarelas dorsais. Apêndices abdominais\r\nsuperiores de comprimento semelhante a S10, notoriamente bifurcados (elemento de diagnóstico)\r\ne sem curvatura para baixo. Nas ASAS, triângulos constituídos por uma única célula; entre sete ou\r\noito e dez nervuras postnodais perpendiculares, até ao pterostigma; PTEROSTIGMAS das asas anteriores\r\nligeiramente mais curtos do que os das posteriores. PATAS com linhas amarelas apenas nos fémures.','Espécie com distribuição muito limitada, restrita apenas a alguns locais em Portugal, Espanha e França.\r\nUma raridade no Algarve.','Knijf & Demolder (2010)\r\nLohr (2005)\r\nVieira et al. (2010)','Gomphidae'),('Gomphus pulchellus','Western Clubtail','Estável','Selys',1840,'LC (Least Concern)','_ABR_MAI_JUN_JUL:','Os adultos têm cerca de 48 mm de comprimento total. OLHOS azuis acinzentados; fronte amarela. No\r\nTÓRAX, em visão lateral, todas as faixas negras são finas (elementos de diagnóstico fundamentais); a faixa\r\namarela entre as duas faixas negras da parte anterior do tórax é muito mais larga do que a primeira\r\nfaixa negra (a contígua à carena dorsal); segunda faixa negra pode ser incompleta e é sempre muito mais\r\nfina do que a faixa amarela entre as segunda e terceira faixas negras; quarta faixa negra percorre toda a\r\nface lateral do tórax e tem uma curvatura muito percetível (elemento de diagnóstico fundamental) acima\r\ndo metastigma. No ABDÓMEN, não há ou é mínima a dilatação em S8 e S9; todos os segmentos com\r\nmanchas amarelas dorsais. No MACHO, apêndices abdominais superiores de comprimento semelhante a\r\nS10, ligeiramente bifurcados nas extremidades e a apontarem para fora (elemento de diagnóstico), mas\r\nsem curvatura para baixo. Nas ASAS, triângulos constituídos por uma única célula; entre sete ou oito e\r\ndez nervuras postnodais perpendiculares, até ao pterostigma; PTEROSTIGMAS das asas anteriores ligeiramente\r\nmais curtos do que os das posteriores; ângulo anal relativamente pronunciado. PATAS com linhas\r\namarelas nos fémures e tíbias.','Ampla distribuição por Portugal, Espanha, França e Alemanha; distribuição limitada no Algarve. Ovip.PR\r\nou ovip.AF.','Gardiner & Sturgess (1995)\r\nKnijf & Demolder (2010)\r\nLohr (2005)\r\nMcLachlan (1880)\r\nVieira et al. (2010)\r\nWeihrauch & Weihrauch (2003)','Gomphidae'),('Lestes barbarus','Migrant Spreadwing','Estável','Fabricius',1798,'LC (Least Concern)','_MAI_JUN_JUL:','Os adultos têm cerca de 42 mm de comprimento total (elemento de diagnóstico particularmente útil na\r\ndiferenciação com L. virens). OLHOS acastanhados ou amarelados. Parte posterior e inferior da cabeça,\r\nentre as peças bucais e o pronotum, amarelada. No TÓRAX, linha castanha muito clara sobre a carena\r\ndorsal, fina mas bem percetível; faixas anteumerais notoriamente largas. No ABDÓMEN, tanto no MACHO\r\ncomo na FÊMEA, a cor amarelada ventral estende-se para a face dorsal de S9 e S10, ficando apenas a verde\r\nou bronze, metálico, uma banda dorsal que, no macho adulto, pode ser coberta por muito ligeira pruinescência\r\nazulada. Apêndices abdominais superiores, no MACHO, amarelados, com as extremidades escuras;\r\ninferiores de tamanho médio, com as extremidades a apontar para fora (elemento de diagnóstico).\r\nPTEROSTIGMAS estendendo-se por duas células alares adjacentes, bicromáticos, com a parte distal (entre\r\num terço e metade) de cor quase branca e a parte restante acastanhada; os pterostigmas são elemento de\r\ndiagnóstico fundamental, embora possa haver, eventualmente, confusão com L. virens; nos tenerals a distinção\r\nentre as duas cores dos pterostigmas pode não ser ainda percetível. PATAS castanhas muito claras,\r\ncom uma linha negra a todo o comprimento do fémur e tíbia.','Poderá ser considerada uma raridade no Algarve. Distribuída por toda a Europa e, pontualmente, no\r\nnorte de África. Embora a espécie não surja listada em qualquer das publicações referidas na Introdução\r\ndeste Guia Digital, Boulot et al. 2009 assinalam já a sua ocorrência na região, numa posição concordante\r\ncom a agora cartografada.',' ','Lestidae'),('Lestes virens','Small Spreadwing','Estável','Charpentier',1825,'LC (Least Concern)','_ABR_MAI_JUN_JUL_AGO_SET:','Os adultos são pequenos e só raramente têm comprimento total superior a 39 mm (elemento de diagnós-tico, em particular para a diferenciação com L. barbarus). OLHOS azulados e muito evidentes no MACHO, \r\nembora no imaturo possam ser castanhos; na FÊMEA o azul é mais discreto ou até inexistente. Parte supe-rior da cabeça verde ou bronze metálicos, e partes posterior e inferior, entre as peças bucais e o prono-tum, amarelas. TÓRAX e ABDÓMEN de cores bronze ou verde e com reflexos metálicos; no TÓRAX, faixas \r\nanteumerais finas e contínuas. No MACHO, pruinescência azulada intensa (elemento de diagnóstico) no \r\nABDÓMEN, em S9 e S10, mas nunca em S1, S2 e S8. Apêndices abdominais superiores, nos adultos, ama-relados e com as extremidades escuras; inferiores muito pequenos (elemento de diagnóstico). PTEROS-TIGMAS monocromáticos, acastanhados (nunca cinzentos muito escuros ou negros); por vezes o terço \r\ndistal é mais claro, suscitando confusão com L. barbarus; esta forma de pigmentação dos pterostigmas \r\nparece ser comum no Algarve. Os pterostigmas do teneralsão monocromáticos e quase brancos.','Existem duas ssp.: virense vestalis. Nas fêmeas adultas da ssp. virenso verde metálico não atinge a sutura \r\nmetapleural; nas da ssp. vestalisatinge. Espécie presente em praticamente toda a Europa, embora não na \r\nparte sudeste da Península Ibérica. No Algarve tem distribuição limitada.','Knijf & Demolder (2010) Lohr (2005)','Lestidae'),('Macromia splendens','Splendid Cruiser','Decréscimo','Pictet',1843,'VU (Vulnerável)','_ABR_MAI:','Cerca de 72 mm de comprimento total. OLHOS verdes, fronte amarela e negra. TÓRAX verde escuro, com\r\nreflexos metálicos verdes ou acobreados; duas faixas amarelas largas e oblíquas, uma em posição anteumeral\r\ne a outra metapleural (elemento de diagnóstico); faixa amarela dorsal na face anterior. ABDÓMEN\r\ncinzento escuro ou quase negro, com manchas amarelas; ligeira dilatação a partir de S7; em visão dorsal,\r\nfaixa amarela em S2, manchas amarelas entre S3 e S4 ou S5, a decrescer progressivamente de dimensão,\r\nmancha amarela percetível em S7 (elemento de diagnóstico). No MACHO, apêndices abdominais superiores\r\nlongos e robustos, tocando-se nas extremidades distais; inferior ligeiramente mais longo. ASA ANTERIOR\r\ncom cerca de quinze nervuras antenodais perpendiculares (elemento de diagnóstico fundamental);\r\nna ASA POSTERIOR, loop anal com seis a nove células; membrânulas brancas. PATAS negras e grandes.','Por vezes designada como Cordulia splendens. Esta raridade é a única espécie, entre as 51 que ocorrem\r\nno Algarve, classificada na The IUCN Red List of Threatened Species com o estatuto de VU - Vulnerable\r\n(vulnerável); todas as restantes apresentam estatutos de risco menos preocupantes.','Lohr (2005)\r\nWeihrauch & Weihrauch (2003)','Macromiidae'),('Oxygastra curtisii','Orange-spotted Emerald','Estável','Dale',1834,'NT (Near Threatened)','_ABR_MAI_JUN:','Os adultos têm cerca de 50 mm de comprimento total. OLHOS e fronte verdes. ABDÓMEN delgado e significativamente\r\nlongo, com manchas dorsais amarelas entre S1 e S7; S10 com uma crosta dorsal amarela\r\nbastante percetível. Apêndices superiores do macho mais curtos do que S9+S10 e terminando cada\r\num com uma ponta curvada para baixo e para o exterior; apêndice inferior robusto. Na fêmea apêndices\r\ndiminutos. Membranas das ASAS predominantemente transparentes, embora possam ser, no MACHO, ligeiramente\r\namareladas nas células proximais; na FÊMEA e no IMATURO o amarelo é, em geral, mais estendido;\r\nASA ANTERIOR com, no máximo, nove nervuras antenodais perpendiculares; triângulos das asas\r\nanteriores e posteriores formados por uma única célula; membrânulas brancas e bastante evidentes. PATAS\r\nescuras e longas.','Distribuição limitada no Algarve, aparentemente ausente no Alentejo, mas a surgir novamente a norte\r\ndo Tejo. Na Europa ocorre também em França e pontualmente em Espanha e Itália. Em Marrocos ocorre\r\nde forma muito limitada. Terr.VA.','Knijf & Demolder (2010)\r\nLohr (2005)\r\nWeihrauch & Weihrauch (2003)','Corduliidae'),('Platycnemis acutipennis','Orange Featherleg','Estável','Selys',1841,'LC (Least Concern)','_ABR_MAI_JUN_JUL:','Os adultos têm cerca de 36 mm de comprimento total. No MACHO adulto os OLHOS são azuis (elemento\r\nde diagnóstico); no teneral são castanhos; o TÓRAX é verde muito claro e, para além da faixa negra na carena\r\ndorsal, destacam-se duas linhas negras paralelas (elemento de diagnóstico), uma sobre a sutura\r\numeral e outra imediatamente abaixo; o ABDÓMEN é cor de laranja, com marcas escuras de S7 a S9; os\r\napêndices abdominais superiores são bífidos e mais curtos do que os inferiores; as PATAS não são achatadas\r\ncomo é caraterístico da Família, e são de cor verde pálido com uma linha fina negra a todo o comprimento.\r\nA FÊMEA é predominantemente castanha clara ou laranja muito ténue; as duas linhas negras paralelas\r\nno TÓRAX, muito semelhantes às do macho, são elemento de diagnóstico fundamental; no ABDÓ-\r\nMEN há uma faixa negra dorsal bastante evidente e que se prolonga por quase todos os segmentos; as\r\ntíbias são ligeiramente mais dilatadas do que as do macho.','Oviposição em tandem (ovip.TD). Espécie endémica da Europa, que ocorre apenas na Península Ibérica e\r\nem França. Distribuição alargada no Algarve. Os adultos podem observar-se nas proximidades dos volumes\r\nde água, mas também a metros de distância dos mesmos.\r\nA observação nas proximidades de São Marcos da Serra, publicada por McLachlan (1880), é o primeiro\r\nregisto da ocorrência da espécie em Portugal continental (Ferreira et al. 2006).','Knijf & Demolder (2010)\r\nLohr (2005)\r\nMcLachlan (1880)\r\nWeihrauch & Weihrauch (2003)','Platycnemididae'),('Platycnemis latipes','White Featherleg','Estável','Rambur',1842,'LC (Least Concern)','_MAR_ABR_AGO:MAI_JUN_JUL','Os adultos têm cerca de 35 mm de comprimento total. No MACHO destaca-se a cor branca ou azul muito\r\nclara (elemento de diagnóstico fundamental), predominante nos OLHOS e no ABDÓMEN; a face dorsal do\r\nprotórax é negra; o TÓRAX é castanho muito claro, exceção para a larga faixa negra na carena dorsal,\r\npara a linha igualmente negra na sutura umeral e para outra linha muito fina, incompleta ou até inexistente,\r\nentre as suturas umeral e interpleural; no ABDÓMEN, a parte dorsal de S6 a S9 é cinzenta ou negra\r\n(elemento de diagnóstico), se bem que a extensão das manchas seja muito variável; as PATAS são acentuadamente\r\nachatadas e dilatadas, brancas e com uma linha negra nos fémures (elemento de diagnóstico\r\nfundamental); os apêndices abdominais superiores são pontiagudos e mais curtos do que os inferiores.\r\nNa FÊMEA predomina também a coloração clara, quase branca, embora no TÓRAX o castanho seja mais\r\nintenso (elemento de diagnóstico); os OLHOS são igualmente castanhos e as PATAS não são tão carateristicamente\r\nachatadas e dilatadas. Machos e fêmeas têm PTEROSTIGMAS castanhos escuros.','Ocorre apenas na Península Ibérica e na parte sudoeste de França. Distribuição alargada no Algarve,\r\ncom algumas populações muito numerosas. Oviposição em tandem (ovip.TD). Espécie univoltina (Corbet\r\net al. 2006).','Ferreira & Grosso-Silva (2006)\r\nKnijf & Demolder (2010)\r\nLohr (2005)','Platycnemididae');
/*!40000 ALTER TABLE `especie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especie_has_habitats`
--

DROP TABLE IF EXISTS `especie_has_habitats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especie_has_habitats` (
  `especie_nome` varchar(45) NOT NULL,
  `habitats_idhabitats` int(11) NOT NULL,
  PRIMARY KEY (`especie_nome`,`habitats_idhabitats`),
  KEY `fk_especie_has_habitats_habitats1_idx` (`habitats_idhabitats`),
  KEY `fk_especie_has_habitats_especie1_idx` (`especie_nome`),
  CONSTRAINT `fk_especie_has_habitats_especie1` FOREIGN KEY (`especie_nome`) REFERENCES `especie` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_especie_has_habitats_habitats1` FOREIGN KEY (`habitats_idhabitats`) REFERENCES `habitats` (`idhabitats`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especie_has_habitats`
--

LOCK TABLES `especie_has_habitats` WRITE;
/*!40000 ALTER TABLE `especie_has_habitats` DISABLE KEYS */;
INSERT INTO `especie_has_habitats` VALUES ('Aeshna cyanea',2),('Calopteryx haemorrhoidalis',2),('Calopteryx virgo meridionalis',2),('Ceriagrion tenellum',2),('Cordulegaster boltonii',2),('Crocothemis erythraea',2),('Gomphus graslinii',2),('Gomphus pulchellus',2),('Macromia splendens',2),('Oxygastra curtisii',2),('Platycnemis acutipennis',2),('Platycnemis latipes',2),('Ceriagrion tenellum',3),('Crocothemis erythraea',3),('Aeshna cyanea',4),('Calopteryx haemorrhoidalis',4),('Crocothemis erythraea',4),('Gomphus graslinii',4),('Gomphus pulchellus',4),('Lestes virens',4),('Macromia splendens',4),('Oxygastra curtisii',4),('Platycnemis acutipennis',4),('Platycnemis latipes',4),('Calopteryx haemorrhoidalis',5),('Calopteryx virgo meridionalis',5),('Cordulegaster boltonii',5),('Crocothemis erythraea',5),('Oxygastra curtisii',5),('Platycnemis acutipennis',5),('Calopteryx haemorrhoidalis',6),('Ceriagrion tenellum',6),('Crocothemis erythraea',6),('Oxygastra curtisii',6),('Platycnemis acutipennis',6),('Platycnemis latipes',6),('Ceriagrion tenellum',7),('Coenagrion puella',7),('Coenagrion scitulum',7),('Crocothemis erythraea',7),('Gomphus pulchellus',7),('Lestes virens',7),('Platycnemis latipes',7),('Aeshna isoceles',8),('Crocothemis erythraea',8),('Lestes virens',8),('Crocothemis erythraea',9),('Gomphus pulchellus',9),('Crocothemis erythraea',10),('Crocothemis erythraea',12),('Lestes barbarus',12),('Lestes virens',12),('Brachythemis impartita',13),('Cordulegaster boltonii',13),('Crocothemis erythraea',13),('Gomphus pulchellus',13);
/*!40000 ALTER TABLE `especie_has_habitats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estadio_ciclo_vida`
--

DROP TABLE IF EXISTS `estadio_ciclo_vida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estadio_ciclo_vida` (
  `nome` varchar(45) NOT NULL,
  `descricao` text,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estadio_ciclo_vida`
--

LOCK TABLES `estadio_ciclo_vida` WRITE;
/*!40000 ALTER TABLE `estadio_ciclo_vida` DISABLE KEYS */;
INSERT INTO `estadio_ciclo_vida` VALUES ('A','adulto'),('Ac','adultos em cópula'),('Ao','fêmea em oviposição'),('At','adultos em tandem'),('E','exuvia'),('Em','emergência '),('L','larva'),('O','ovo'),('T','imaturo recém-emergido');
/*!40000 ALTER TABLE `estadio_ciclo_vida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado_contributo`
--

DROP TABLE IF EXISTS `estado_contributo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado_contributo` (
  `nome` varchar(45) NOT NULL,
  `descricao` text,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_contributo`
--

LOCK TABLES `estado_contributo` WRITE;
/*!40000 ALTER TABLE `estado_contributo` DISABLE KEYS */;
INSERT INTO `estado_contributo` VALUES ('a aguardar submissão','contributo está aberto a ser editado antes de ser submetido ao sistema'),('aceite','contributo foi aceite no sistema'),('rejeitado','contributo foi rejeitado no sistema'),('submetido','contributo está à espera de ser aceite ou rejeitado pelo sistema');
/*!40000 ALTER TABLE `estado_contributo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `familia`
--

DROP TABLE IF EXISTS `familia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `familia` (
  `nome` varchar(45) NOT NULL,
  `descricao` text,
  `sub_ordem_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`nome`),
  KEY `fk_Familia_sub_ordem1_idx` (`sub_ordem_nome`),
  CONSTRAINT `fk_Familia_sub_ordem1` FOREIGN KEY (`sub_ordem_nome`) REFERENCES `sub_ordem` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `familia`
--

LOCK TABLES `familia` WRITE;
/*!40000 ALTER TABLE `familia` DISABLE KEYS */;
INSERT INTO `familia` VALUES ('Aeshnidae',NULL,'Anisoptera'),('Calopterygidae',NULL,'Zygoptera'),('Coenagrionidae','asd','Zygoptera'),('Cordulegastridae',NULL,'Anisoptera'),('Corduliidae',NULL,'Anisoptera'),('Gomphidae',NULL,'Anisoptera'),('Lestidae',NULL,'Zygoptera'),('Libellulidae',NULL,'Anisoptera'),('Macromiidae',NULL,'Anisoptera'),('Platycnemididae',NULL,'Zygoptera');
/*!40000 ALTER TABLE `familia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `familia_has_atributos_familia`
--

DROP TABLE IF EXISTS `familia_has_atributos_familia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `familia_has_atributos_familia` (
  `familia_nome` varchar(45) NOT NULL,
  `atributos_familia_idatributos_familia` int(11) NOT NULL,
  PRIMARY KEY (`familia_nome`,`atributos_familia_idatributos_familia`),
  KEY `fk_familia_has_atributos_familia_atributos_familia1_idx` (`atributos_familia_idatributos_familia`),
  KEY `fk_familia_has_atributos_familia_familia1_idx` (`familia_nome`),
  CONSTRAINT `fk_familia_has_atributos_familia_atributos_familia1` FOREIGN KEY (`atributos_familia_idatributos_familia`) REFERENCES `atributos_familia` (`idatributos_familia`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_familia_has_atributos_familia_familia1` FOREIGN KEY (`familia_nome`) REFERENCES `familia` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `familia_has_atributos_familia`
--

LOCK TABLES `familia_has_atributos_familia` WRITE;
/*!40000 ALTER TABLE `familia_has_atributos_familia` DISABLE KEYS */;
INSERT INTO `familia_has_atributos_familia` VALUES ('Aeshnidae',5),('Aeshnidae',6),('Aeshnidae',7),('Aeshnidae',11),('Aeshnidae',12),('Aeshnidae',13),('Aeshnidae',14),('Aeshnidae',18),('Aeshnidae',20);
/*!40000 ALTER TABLE `familia_has_atributos_familia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ficha_especie`
--

DROP TABLE IF EXISTS `ficha_especie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ficha_especie` (
  `idficha_especie` int(11) NOT NULL AUTO_INCREMENT,
  `mapa_especie` text,
  `especie_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idficha_especie`),
  KEY `fk_ficha_especie_especie1_idx` (`especie_nome`),
  CONSTRAINT `fk_ficha_especie_especie1` FOREIGN KEY (`especie_nome`) REFERENCES `especie` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ficha_especie`
--

LOCK TABLES `ficha_especie` WRITE;
/*!40000 ALTER TABLE `ficha_especie` DISABLE KEYS */;
/*!40000 ALTER TABLE `ficha_especie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fotos`
--

DROP TABLE IF EXISTS `fotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fotos` (
  `idfotos` int(11) NOT NULL AUTO_INCREMENT,
  `nome` text,
  `path` text,
  `legenda` text,
  `contributos_idcontributos` int(11) NOT NULL,
  PRIMARY KEY (`idfotos`),
  KEY `fk_fotos_contributos1_idx` (`contributos_idcontributos`),
  CONSTRAINT `fk_fotos_contributos1` FOREIGN KEY (`contributos_idcontributos`) REFERENCES `contributos` (`idcontributos`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fotos`
--

LOCK TABLES `fotos` WRITE;
/*!40000 ALTER TABLE `fotos` DISABLE KEYS */;
INSERT INTO `fotos` VALUES (2,'8_foto1.jpeg','fotoPath','imagem',8),(3,'8_foto2.jpeg','fotoPath','foto',8);
/*!40000 ALTER TABLE `fotos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitats`
--

DROP TABLE IF EXISTS `habitats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `habitats` (
  `idhabitats` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` text,
  `subtipos_habitats_idsubtipos_habitats` int(11) NOT NULL,
  PRIMARY KEY (`idhabitats`),
  KEY `fk_habitats_subtipos_habitats1_idx` (`subtipos_habitats_idsubtipos_habitats`),
  CONSTRAINT `fk_habitats_subtipos_habitats1` FOREIGN KEY (`subtipos_habitats_idsubtipos_habitats`) REFERENCES `subtipos_habitats` (`idsubtipos_habitats`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitats`
--

LOCK TABLES `habitats` WRITE;
/*!40000 ALTER TABLE `habitats` DISABLE KEYS */;
INSERT INTO `habitats` VALUES (1,'Rio Guadiana (o único grande rio)',1),(2,'Outros rios e ribeiras de regime hidrológico permanente',1),(3,'Canais de rega',1),(4,'Ribeiras na serra algarvia (em xistos e grauvaques, do Carbónico)',2),(5,'Ribeiras montanhosas (acima dos 400 m de altitude) nas serras de Monchique (em rochas eruptivas) e do Caldeirão (em xistos e grauvaques, do Carbónico)',2),(6,'Ribeiras no barrocal e litoral algarvios',2),(7,'Pequenos charcos (com ou sem açude) e lagoas naturais, permanentes (< 8 ha ≈ 0,08 km2)',3),(8,'Pequenos charcos (com ou sem açude) e lagoas naturais, temporários (< 8 ha ≈ 0,08 km2)',3),(9,'Grandes lagoas naturais permanentes e albufeiras de barragens (≥ 8 ha ≈ 0,08 km2)',3),(10,'Pauis e arrozais',3),(11,'Pequenos pontos de água (fontes, tanques em jardins públicos, bebedouros de animais, etc.)',3),(12,'Sapais e salinas abandonadas',4),(13,'Locais afastados (mais de 100m) de qualquer volume de água',5);
/*!40000 ALTER TABLE `habitats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagens`
--

DROP TABLE IF EXISTS `imagens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagens` (
  `idimagens` int(11) NOT NULL AUTO_INCREMENT,
  `nome` text,
  `path` text,
  `legenda` text,
  `especie_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idimagens`),
  KEY `fk_imagens_especie1_idx` (`especie_nome`),
  CONSTRAINT `fk_imagens_especie1` FOREIGN KEY (`especie_nome`) REFERENCES `especie` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagens`
--

LOCK TABLES `imagens` WRITE;
/*!40000 ALTER TABLE `imagens` DISABLE KEYS */;
INSERT INTO `imagens` VALUES (16,'Lestes_virens_imagem1.jpeg','imagensEspeciePath','MALE - July 2011 - Â© NSL','Lestes virens'),(17,'Lestes_virens_imagem2.jpeg','imagensEspeciePath','EMERGENCE - May 2012 - Â© NSL','Lestes virens'),(20,'Lestes_virens_imagemPrincipal.jpeg','imagensEspeciePath','asd','Lestes virens'),(21,'Aeshna_cyanea_imagemPrincipal.png','imagensEspeciePath','Aeshna Cyanea','Aeshna cyanea'),(22,'Brachythemis_impartita_imagemPrincipal.png','imagensEspeciePath','Calopteryx Haemorrhoidalis','Brachythemis impartita'),(23,'Ceriagrion_tenellum_imagemPrincipal.png','imagensEspeciePath','Ceriagrion Tenellum','Ceriagrion tenellum'),(24,'Coenagrion_puella_imagemPrincipal.png','imagensEspeciePath','Coenagrion Puella','Coenagrion puella'),(25,'Coenagrion_scitulum_imagemPrincipal.png','imagensEspeciePath','Coenagrion Scitulum','Coenagrion scitulum'),(26,'Crocothemis_erythraea_imagemPrincipal.jpeg','imagensEspeciePath','test','Crocothemis erythraea');
/*!40000 ALTER TABLE `imagens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordem`
--

DROP TABLE IF EXISTS `ordem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordem` (
  `nome` varchar(45) NOT NULL,
  `descricao` text,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordem`
--

LOCK TABLES `ordem` WRITE;
/*!40000 ALTER TABLE `ordem` DISABLE KEYS */;
INSERT INTO `ordem` VALUES ('Odonata','asdasd');
/*!40000 ALTER TABLE `ordem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_ordem`
--

DROP TABLE IF EXISTS `sub_ordem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_ordem` (
  `nome` varchar(45) NOT NULL,
  `descricao` text,
  `ordem_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`nome`),
  KEY `fk_sub_ordem_ordem1_idx` (`ordem_nome`),
  CONSTRAINT `fk_sub_ordem_ordem1` FOREIGN KEY (`ordem_nome`) REFERENCES `ordem` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_ordem`
--

LOCK TABLES `sub_ordem` WRITE;
/*!40000 ALTER TABLE `sub_ordem` DISABLE KEYS */;
INSERT INTO `sub_ordem` VALUES ('Anisoptera',NULL,'Odonata'),('Zygoptera',NULL,'Odonata');
/*!40000 ALTER TABLE `sub_ordem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_ordem_has_atributos_sub_ordem`
--

DROP TABLE IF EXISTS `sub_ordem_has_atributos_sub_ordem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_ordem_has_atributos_sub_ordem` (
  `sub_ordem_nome` varchar(45) NOT NULL,
  `atributos_sub_ordem_idatributos_sub_ordem` int(11) NOT NULL,
  PRIMARY KEY (`sub_ordem_nome`,`atributos_sub_ordem_idatributos_sub_ordem`),
  KEY `fk_sub_ordem_has_atributos_sub_ordem_atributos_sub_ordem1_idx` (`atributos_sub_ordem_idatributos_sub_ordem`),
  KEY `fk_sub_ordem_has_atributos_sub_ordem_sub_ordem1_idx` (`sub_ordem_nome`),
  CONSTRAINT `fk_sub_ordem_has_atributos_sub_ordem_atributos_sub_ordem1` FOREIGN KEY (`atributos_sub_ordem_idatributos_sub_ordem`) REFERENCES `atributos_sub_ordem` (`idatributos_sub_ordem`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_sub_ordem_has_atributos_sub_ordem_sub_ordem1` FOREIGN KEY (`sub_ordem_nome`) REFERENCES `sub_ordem` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_ordem_has_atributos_sub_ordem`
--

LOCK TABLES `sub_ordem_has_atributos_sub_ordem` WRITE;
/*!40000 ALTER TABLE `sub_ordem_has_atributos_sub_ordem` DISABLE KEYS */;
INSERT INTO `sub_ordem_has_atributos_sub_ordem` VALUES ('Zygoptera',1),('Anisoptera',2),('Zygoptera',3),('Anisoptera',4),('Zygoptera',5),('Anisoptera',6),('Zygoptera',7),('Anisoptera',8),('Zygoptera',9),('Anisoptera',10),('Zygoptera',11),('Anisoptera',12);
/*!40000 ALTER TABLE `sub_ordem_has_atributos_sub_ordem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subtipos_habitats`
--

DROP TABLE IF EXISTS `subtipos_habitats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subtipos_habitats` (
  `idsubtipos_habitats` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` text,
  `tipos_habitats_idtipos_habitats` int(11) NOT NULL,
  PRIMARY KEY (`idsubtipos_habitats`),
  KEY `fk_subtipos_habitats_tipos_habitats1_idx` (`tipos_habitats_idtipos_habitats`),
  CONSTRAINT `fk_subtipos_habitats_tipos_habitats1` FOREIGN KEY (`tipos_habitats_idtipos_habitats`) REFERENCES `tipos_habitats` (`idtipos_habitats`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subtipos_habitats`
--

LOCK TABLES `subtipos_habitats` WRITE;
/*!40000 ALTER TABLE `subtipos_habitats` DISABLE KEYS */;
INSERT INTO `subtipos_habitats` VALUES (1,'Sistemas lóticos simples',1),(2,'Sistemas lóticos complexos',1),(3,'Sistemas lênticos',1),(4,'Sapais e Salinas abandonadas',1),(5,'Locais afastados (mais de 100m) de qualquer volume de água',2);
/*!40000 ALTER TABLE `subtipos_habitats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `textos_introdutorios`
--

DROP TABLE IF EXISTS `textos_introdutorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `textos_introdutorios` (
  `nome` varchar(45) NOT NULL,
  `texto` text NOT NULL,
  `utilizadores_nome_utilizador` varchar(45) NOT NULL,
  `idtextos_introdutorios` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idtextos_introdutorios`),
  UNIQUE KEY `nome_UNIQUE` (`nome`),
  KEY `fk_textos_introdutorios_utilizadores1_idx` (`utilizadores_nome_utilizador`),
  CONSTRAINT `fk_textos_introdutorios_utilizadores1` FOREIGN KEY (`utilizadores_nome_utilizador`) REFERENCES `utilizadores` (`nome_utilizador`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `textos_introdutorios`
--

LOCK TABLES `textos_introdutorios` WRITE;
/*!40000 ALTER TABLE `textos_introdutorios` DISABLE KEYS */;
INSERT INTO `textos_introdutorios` VALUES ('OBSERVAR LIBÉLULAS E LIBELINHAS','A observação de Odonata adultos tem semelhanças com o birdwatching. É fundamental conhecer o ciclo de vida e os hábitos destes insetos, e é indispensável conhecer os habitats preferidos por cada espécie. São muito úteis os binóculos, devem vestir-se roupas de cores discretas, caminhar tranquilamente e, particularmente, aguardar em pontos estratégicos. Os modelos ideais de binóculos têm ampliação de 7 ou 8 vezes e distância mínima de focagem reduzida (CF, acrónimo de close-focusing), especificações técnicas que devem ser associadas à robustez indispensável para uso intensivo no campo. A generalidade das marcas conceituadas produz e comercializa diversos modelos e, entre outras opções possíveis, podem-se referir os Pentax Papilio (CF = 0,5 m) e os Steiner SkyHawk Pro 8x32 (2,0 m). No entanto, a identificação até ao nível taxonómico base, ou seja, até à Espécie, baseada apenas em observações efémeras, feitas a olho nu ou com o auxílio de binóculos, pode ser difícil ou mesmo impossível, em particular se o objetivo é um rigoroso censo da ocorrência de Odonata num território. A prudência científica recomenda que a identificação feita nas condições acima descritas seja considerada fiável apenas até ao nível taxonómico da Família ou Género e, sendo possível, que se recorra a procedimentos complementares de identificação, como a fotografia macro, a observação à lupa, no campo e eventualmente no laboratório, de larvas e exuviae, ou a cuidadosa captura dos adultos com uma rede para borboletas, imediatamente seguida da identificação inequívoca e libertação dos exemplares. A rede para captura de Odonata deverá ser adequada à Subordem: para a Zygoptera recomenda-se uma pequena e de cabo curto; para a Anisoptera é preferível uma significativamente maior e de cabo longo. Por exemplo, diâmetros de abertura das redes de 40 cm e 65 cm, e cabos (preferencialmente extensíveis) de 90 e 180 cm. Por fim, para além dos binóculos e/ou do equipamento fotográfico, e eventualmente das redes para captura não letal de specimens, ao especialista em Odonata não deve faltar o caderno de campo e o GPS. No caderno registará sistematicamente espécies, habitats, datas e outras anotações relevantes; o GPS permitir-lhe-á conhecer com rigor as coordenadas geográficas do local. A Garmin, por exemplo, é uma marca conceituada, com diversos modelos robustos e fiáveis para uso intensivo em outdoor (eTrex).','admin',1),('ECOLOGIA, BIOLOGIA E TAXONOMIA','As Odonata, como a quase totalidade das espécies da classe INSECTA, têm o corpo constituído \r\npor três secções: cabeça, tóraxe abdómen. Na cabeça(head) existem dois grandes olhos (eyes), \r\ntrês ocelos (ocellae) e duas pequenas antenas (antennae). O sentido da visão é muito desenvol-vido, para a forma e cor, e igualmente para o movimento. Os olhos são proeminentes, compos-tos, ocupam grande parte da cabeça e asseguram um amplo campo de visão. Os outros senti-dos, pelo contrário, são rudimentares ou até inexistentes. O diminuto tamanho das antenas, \r\nque são órgãos olfativos, evidencia a pouca sensibilidade das libélulas e libelinhas aos cheiros e \r\naromas. Na cabeça também se destacam as várias peças bucais (mouthparts) mastigadoras, for-tes e sobressalientes, indicadoras de um comportamento predador e voraz. Aliás, a palavra \r\nOdonataencontra a sua raiz etimológica em odontos, o termo grego para dentes, consequên-cia direta dos numerosos dentes de apreciável tamanho que existem nas mandíbulas.\r\nA partir do tórax(thorax), que é formado por uma diminuta parte anterior, o protórax(protho-rax), e por uma posterior principal, o pterotórax(pterothorax or synthorax), surgem dois pares \r\nde asas(wings), o anterior(Fw: forewings) e o posterior(Hw: hindwings), e três pares de patas\r\n(legs). Estas últimas, relativamente compridas, são constituídas por quatro segmentos, coxa, \r\nfémur, tíbiae tarso(coxa, femur, tibia and tarsus), e não estão adaptadas para a marcha, permi-tindo apenas ao inseto pousar e fazer deslocações muito limitadas; em oposição, estão dotadas \r\nde cerdas(bristles), tornando-as particularmente aptas para otimizar a eficácia da caça durante \r\no voo. Os dois pares de asas são bastante grandes. Têm uma rede estruturada de nervuras (veins\r\n- venation) e membranas (membranes) bastante percetível, frequentemente utilizada para iden-tificar as Famílias e, frequentemente, as Espécies. O movimento das asas anteriores e posteriores \r\né controlado de forma independente; o ritmo de batimento é de 20 a 40 movimentos por se-gundo. As Odonataatingem velocidades de voo da ordem dos 60 quilómetros por hora, a pre-cisão das trajetórias é enorme, podem ficar completamente estáticas no ar e, até, voar para trás.\r\nO abdómen(abdomen) é consideravelmente longo, relativamente cilíndrico, fino e constituído \r\npor dez segmentos (abdominal segments: em acrónimo indicados como de S1 a S10, numerados \r\ndo tórax para a extremidade posterior). No tórax e ao longo do abdómen existem os espirácu-los(spiracles), dez pares no total, um no tórax, designado metastigma(metastigma), e os res-tantes no abdómen; é através dos espiráculosque as libélulas e libelinhas adultas respiram.\r\nO dimorfismo sexualnas Odonataadultas é evidente e facilmente percetível. Os elementos de \r\ndiagnósticofundamentais são: i. órgãos genitais externos; ii. cor. Os machos têm, na extremi-dade posterior do abdómen, apêndices abdominais(abdominal appendages) destinados a \r\nagarrar as fêmeas antes e durante o acasalamento (ou cópula) e, eventualmente, a oviposição; \r\ntêm, igualmente, órgãos genitais secundários(secondary or accessory male genitalia), localiza-dos na face ventral de S2, constituídos pela fossa genital(genital fossa) e por outras estruturas \r\ncomplementares. O órgão copulatório, designado de vesica spermalisou pseudo-pénis, está \r\nposicionado na fossa genital. Os apêndices abdominais superioressão sempre dois; os inferiores\r\nsão dois ou apenas um, consoante as Famílias e Subordens; sob um ponto de vista funcional, o \r\nnúmero de apêndices abdominais masculinos condiciona a forma como o macho agarra a fê-mea. Entre as fêmeas há duas estratégias muito diferentes, na tarefa de assegurar a continuida-de das respetivas espécies: i. oviposição endofítica(endophytic oviposition) e ii. oviposição exofí-tica(exophyticoviposition). No primeiro caso, os insetos introduzem os ovos em tecidos vegetais \r\n7\r\nrecorrendo a um ovipositorbem desenvolvido, constituído por apêndices genitaislocalizados \r\nna face ventral de S8 e S9. No segundo, os insetos depositam, em voo, os ovos na superfície livre \r\nda água ou, em alternativa, depositam-nos sobre a superfície de plantas aquáticas (por vezes \r\ndesignada de iii. oviposição epifítica: epiphytic oviposition) ou outros substratos, em contacto \r\ndireto com a água e/ou com elevado teor de humidade; p.ex., pedras, lamas e lodo, vegetação \r\nmarginal aos volumes de água. Os órgãos genitais externos são, então, a vulva(canal ou aber-tura para o exterior, por onde saem os ovos) e a lâmina vulvar(elemento que canaliza os ovos \r\ne facilita a oviposição). As implicações destas duas estratégias distintas são um tema particu-larmente vivo; Philip S. Corbettem referido repetidamente que a oviposição exofítica permite \r\nàs Odonataexplorar novos habitats para as larvas (larval habitat), como os volumes de água \r\ntemporários onde a vegetação aquática é escassa ou inexistente; Natalia A. Matushkinaacres-centou outras variáveis relevantes para a análise, como as posturas depositadas num único local \r\nou espalhadas por áreas mais alargadas, na água ou em outros substratos, com a fêmea pousa-da ou em voo.\r\nA cordo corpo das Odonataresulta da existência de pigmentos, de fenómenos de difração da \r\nluz sobre a cutícula, e da presença, em especial nos machos, de um exsudado produzido na hi-poderme, designado de pruínaou pruinescência(pruinosity or pruinescence), de cores esbran-quiçada, azulada ou violeta. As fêmeas são, em muitas Famílias, menos coloridas e, geralmente, \r\ntêm um padrão de comportamento distinto: estão mais afastadas dos volumes de água. Por \r\nisso, são menos fáceis de observar.','admin',8),('CICLO DE VIDA','O ciclo de vidacompleto das Odonataé constituído por três fases: ovos, larvase adultos\r\n(imagos or imagines). As duas primeiras fases desenrolam-se em meio aquático e a fase final em \r\nmeio aéreo.\r\nEm algumas espécies, logo após a oviposição começa o desenvolvimento (embriogénese) dos \r\novos, o que poderá demorar entre uma e seis semanas; em outras espécies, após um desenvol-vimento inicial, os ovos atravessam um período de dormência fisiológica (diapausa : diapause \r\nstage) durante o inverno, e seguidamente ocorre a formação completa das larvas. A fase larvar\r\nque, por norma, é a mais prolongada, pode variar entre três meses e alguns anos. A plena matu-ridade da fase adulta, especialmente concentrada na função reprodutora, tem, em geral, dura-ção mais curta: quatro a seis semanas para as libélulas e apenas uma a duas para as libelinhas. \r\nPode, no entanto, prolongar-se por um número significativamente maior de semanas.\r\nDurante quase toda a vida, libélulas e libelinhas são predadores insaciáveis, sendo a dieta ali-mentar constituída por recursos vivos de origem animal. O movimento das presas é fundamen-tal para que sejam identificadas. As larvas alimentam-se de ovos de anfíbios e pequenos girinos, \r\nde pequenos peixes, de larvas de outros insetos ou outros invertebrados; por outro lado, peixes \r\ne anfíbios são os principais predadores das larvas das Odonata. Os adultos são exímios caçado-res de outros insetos, capturados pleno em voo. Em contrapartida, as aves são os seus principais \r\npredadores.','admin',9);
/*!40000 ALTER TABLE `textos_introdutorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_utilizadores`
--

DROP TABLE IF EXISTS `tipo_utilizadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_utilizadores` (
  `nome` varchar(45) NOT NULL,
  `descricao` text,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_utilizadores`
--

LOCK TABLES `tipo_utilizadores` WRITE;
/*!40000 ALTER TABLE `tipo_utilizadores` DISABLE KEYS */;
INSERT INTO `tipo_utilizadores` VALUES ('Administrador','Administrador do sistema, pode aprovar contributos submetidos e gerir o sistema'),('Contribuinte','Pode submeter contributos sem a necessidade destes serem aprovados'),('Superadmin','Super administrador. Só existe um no sistema. Tem todos os direitos do sistema'),('Utilizador','Utilizador comum, pode submeter contributos que terão que ser aprovados');
/*!40000 ALTER TABLE `tipo_utilizadores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_habitats`
--

DROP TABLE IF EXISTS `tipos_habitats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos_habitats` (
  `idtipos_habitats` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` text,
  PRIMARY KEY (`idtipos_habitats`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_habitats`
--

LOCK TABLES `tipos_habitats` WRITE;
/*!40000 ALTER TABLE `tipos_habitats` DISABLE KEYS */;
INSERT INTO `tipos_habitats` VALUES (1,'Habitats de reprodução e alimentação'),(2,'Habitats de maturação, alimentação e dispersão');
/*!40000 ALTER TABLE `tipos_habitats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilizadores`
--

DROP TABLE IF EXISTS `utilizadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utilizadores` (
  `nome_utilizador` varchar(45) NOT NULL,
  `nome` text,
  `idade` int(11) DEFAULT NULL,
  `genero` char(1) DEFAULT NULL,
  `morada` text,
  `localidade` text,
  `profissao` text,
  `password` text,
  `tipo_utilizadores_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`nome_utilizador`),
  KEY `fk_utilizadores_tipo_utilizadores1_idx` (`tipo_utilizadores_nome`),
  CONSTRAINT `fk_utilizadores_tipo_utilizadores1` FOREIGN KEY (`tipo_utilizadores_nome`) REFERENCES `tipo_utilizadores` (`nome`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilizadores`
--

LOCK TABLES `utilizadores` WRITE;
/*!40000 ALTER TABLE `utilizadores` DISABLE KEYS */;
INSERT INTO `utilizadores` VALUES ('admin',NULL,NULL,NULL,NULL,NULL,NULL,'admin','Superadmin'),('FCorvelo','Fernando Corvelo',20,'M','morada','faro','estudante','qwerty123','Utilizador');
/*!40000 ALTER TABLE `utilizadores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-07-15 15:36:27
